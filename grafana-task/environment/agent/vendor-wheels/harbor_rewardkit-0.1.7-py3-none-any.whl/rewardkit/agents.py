"""Agent CLI backends for rewardkit judge evaluation."""

from __future__ import annotations

import json
import logging
import os
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import TYPE_CHECKING, Any, override

if TYPE_CHECKING:
    from rewardkit.models import MCPServerConfig

logger = logging.getLogger(__name__)

_REGISTRY: dict[str, type[AgentCLI]] = {}


def force_oauth() -> bool:
    """Whether to prefer a subscription OAuth token over an API key when both are set."""
    return os.environ.get("REWARDKIT_FORCE_OAUTH", "").strip().lower() in (
        "1",
        "true",
        "yes",
    )


class AgentCLI:
    """Base class for agent CLI backends.

    Subclass and call ``register_agent()`` to make an agent available as a TOML judge.
    """

    name: str
    cli_name: str
    install_script: str

    def build_command(
        self,
        prompt: str,
        schema: dict[str, Any],
        allowed_tools: tuple[str, ...] = (),
    ) -> list[str]:
        raise NotImplementedError

    def _mcp_add_args(self, server: MCPServerConfig) -> list[str]:
        """Args after ``<cli> mcp add`` to register *server* (backend-specific)."""
        raise NotImplementedError

    @staticmethod
    def _stdio_mcp_add_args(server: MCPServerConfig) -> list[str]:
        return [server.name, "--", server.command or "", *server.args]

    def add_mcp_servers(
        self, servers: tuple[MCPServerConfig, ...], cwd: str | None = None
    ) -> None:
        """Register each MCP server via ``<cli> mcp add``.

        CLI reference: claude https://code.claude.com/docs/en/mcp,
        codex https://developers.openai.com/codex/mcp.
        """
        for server in servers:
            args = [os.path.expandvars(arg) for arg in self._mcp_add_args(server)]
            cmd = [self.cli_name, "mcp", "add", *args]
            proc = subprocess.run(cmd, capture_output=True, text=True, cwd=cwd)
            # Re-adding an already-registered server exits non-zero; tolerate it
            # so several judges may declare the same server.
            if (
                proc.returncode != 0
                and "already exists" not in (proc.stdout + proc.stderr).lower()
            ):
                raise subprocess.CalledProcessError(
                    proc.returncode, cmd, output=proc.stdout, stderr=proc.stderr
                )

    def model_args(self, model: str) -> list[str]:
        return ["--model", model]

    def parse_output(self, raw: str) -> str:
        return raw

    def cleanup(self) -> None:
        pass

    def ensure_installed(self) -> None:
        if shutil.which(self.cli_name):
            return
        logger.info("Installing %s...", self.cli_name)
        subprocess.run(
            ["bash", "-c", self.install_script],
            check=True,
            capture_output=True,
        )
        local_bin = str(Path.home() / ".local" / "bin")
        if local_bin not in os.environ.get("PATH", ""):
            os.environ["PATH"] = f"{local_bin}:{os.environ.get('PATH', '')}"
        if not shutil.which(self.cli_name):
            raise FileNotFoundError(
                f"Agent CLI '{self.cli_name}' not found after install attempt"
            )


def register_agent(cls: type[AgentCLI]) -> None:
    _REGISTRY[cls.name] = cls


def get_agent(name: str) -> AgentCLI:
    """Return a fresh instance of the agent backend for *name*."""
    try:
        return _REGISTRY[name]()
    except KeyError:
        known = ", ".join(sorted(_REGISTRY)) or "(none)"
        raise ValueError(f"Unknown agent '{name}'. Known agents: {known}") from None


def known_agents() -> frozenset[str]:
    return frozenset(_REGISTRY)


class ClaudeCodeCLI(AgentCLI):
    name = "claude-code"
    cli_name = "claude"
    install_script = (
        "set -eu; "
        "if command -v apk >/dev/null 2>&1; then"
        "  npm install -g @anthropic-ai/claude-code;"
        " else"
        "  set -o pipefail;"
        "  curl -fsSL https://claude.ai/install.sh | bash;"
        " fi && "
        'export PATH="$HOME/.local/bin:$PATH" && '
        "claude --version"
    )

    @override
    def build_command(
        self,
        prompt: str,
        schema: dict[str, Any],
        allowed_tools: tuple[str, ...] = (),
    ) -> list[str]:
        cmd = [
            "claude",
            "-p",
            prompt,
            "--output-format",
            "json",
            "--json-schema",
            json.dumps(schema),
        ]
        # claude -p will not call MCP (or other) tools without an allowlist.
        if allowed_tools:
            cmd += ["--allowedTools", " ".join(allowed_tools)]
        return cmd

    @override
    def _mcp_add_args(self, server: MCPServerConfig) -> list[str]:
        if server.transport == "stdio":
            return self._stdio_mcp_add_args(server)
        # Claude Code names the streamable-http transport "http".
        transport = (
            "http" if server.transport == "streamable-http" else server.transport
        )
        return ["--transport", transport, server.name, server.url or ""]

    @override
    def model_args(self, model: str) -> list[str]:
        if model.startswith("anthropic/"):
            model = model.removeprefix("anthropic/")
        return ["--model", model]

    @override
    def parse_output(self, raw: str) -> str:
        try:
            envelope = json.loads(raw)
            if isinstance(envelope, dict):
                if envelope.get("is_error"):
                    raise ValueError(
                        f"Claude CLI returned an error: {envelope.get('result', raw[:200])}"
                    )
                if "structured_output" in envelope:
                    return json.dumps(envelope["structured_output"])
        except (json.JSONDecodeError, TypeError):
            pass
        return raw


class CodexCLI(AgentCLI):
    name = "codex"
    cli_name = "codex"
    install_script = (
        "set -eu; "
        "if command -v apk >/dev/null 2>&1; then"
        "  npm install -g @openai/codex@latest;"
        " else"
        "  set -o pipefail;"
        "  curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.2/install.sh | bash &&"
        '  export NVM_DIR="$HOME/.nvm" &&'
        '  . "$NVM_DIR/nvm.sh" || true &&'
        "  command -v nvm >/dev/null 2>&1 || { echo 'Error: NVM failed to load' >&2; exit 1; } &&"
        "  nvm install 22 && nvm alias default 22 && npm install -g @openai/codex@latest &&"
        '  for bin in node codex; do ln -sf "$(which $bin)" "/usr/local/bin/$bin" 2>/dev/null || true; done;'
        " fi && "
        "codex --version"
    )

    def __init__(self) -> None:
        self._schema_path: str | None = None

    @override
    def ensure_installed(self) -> None:
        super().ensure_installed()
        # codex does not read OPENAI_API_KEY on its own, so log in explicitly.
        # Both flags read the credential from stdin.
        access_token = os.environ.get("CODEX_ACCESS_TOKEN")
        api_key = os.environ.get("OPENAI_API_KEY")
        if access_token and (not api_key or force_oauth()):
            flag, credential = "--with-access-token", access_token
        elif api_key:
            flag, credential = "--with-api-key", api_key
        else:
            return
        subprocess.run(
            ["codex", "login", flag],
            input=credential,
            text=True,
            check=True,
            capture_output=True,
        )

    @override
    def build_command(
        self,
        prompt: str,
        schema: dict[str, Any],
        allowed_tools: tuple[str, ...] = (),
    ) -> list[str]:
        fd, self._schema_path = tempfile.mkstemp(suffix=".json")
        with os.fdopen(fd, "w") as f:
            json.dump(schema, f)
        return [
            "codex",
            "exec",
            prompt,
            "--output-schema",
            self._schema_path,
            "--skip-git-repo-check",
        ]

    @override
    def _mcp_add_args(self, server: MCPServerConfig) -> list[str]:
        if server.transport == "stdio":
            return self._stdio_mcp_add_args(server)
        if server.transport == "streamable-http":
            return [server.name, "--url", server.url or ""]
        raise ValueError(
            f"codex agent judge does not support '{server.transport}' MCP "
            f"servers (server '{server.name}'); use stdio or streamable-http."
        )

    @override
    def model_args(self, model: str) -> list[str]:
        return ["-m", model]

    @override
    def cleanup(self) -> None:
        if self._schema_path:
            Path(self._schema_path).unlink(missing_ok=True)
            self._schema_path = None


register_agent(ClaudeCodeCLI)
register_agent(CodexCLI)
