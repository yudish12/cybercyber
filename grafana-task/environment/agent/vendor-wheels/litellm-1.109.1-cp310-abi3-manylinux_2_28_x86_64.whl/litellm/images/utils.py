import base64
import os
from collections.abc import Collection, Mapping
from io import BufferedReader, BytesIO
from pathlib import Path
from typing import Any, Final, Protocol, cast, get_type_hints, runtime_checkable

import litellm
from litellm.litellm_core_utils.token_counter import get_image_type
from litellm.llms.base_llm.image_edit.transformation import BaseImageEditConfig
from litellm.types.files import FILE_MIME_TYPES, FileType
from litellm.types.images.main import ImageEditOptionalRequestParams


class ImageEditRequestUtils:
    @staticmethod
    def get_optional_params_image_edit(
        model: str,
        image_edit_provider_config: BaseImageEditConfig,
        image_edit_optional_params: ImageEditOptionalRequestParams,
        drop_params: bool | None = None,
        additional_drop_params: Collection[str] | None = None,
    ) -> dict[str, object]:
        """
        Get optional parameters for the image edit API.

        Args:
            model: The model name
            image_edit_provider_config: The provider configuration for image edit API
            image_edit_optional_params: The optional parameters for the image edit API
            drop_params: If True, silently drop unsupported parameters instead of raising
            additional_drop_params: List of additional parameter names to drop

        Returns:
            A dictionary of supported parameters for the image edit API
        """
        supported_params: Final = image_edit_provider_config.get_supported_openai_params(model)

        should_drop: Final = litellm.drop_params is True or drop_params is True

        filtered_optional_params: Final = dict(image_edit_optional_params)
        if additional_drop_params:
            for param in additional_drop_params:
                filtered_optional_params.pop(param, None)

        unsupported_params: Final = [param for param in filtered_optional_params if param not in supported_params]

        if unsupported_params:
            if should_drop:
                for param in unsupported_params:
                    filtered_optional_params.pop(param, None)
            else:
                raise litellm.UnsupportedParamsError(
                    model=model,
                    message=f"The following parameters are not supported for model {model}: {', '.join(unsupported_params)}",
                )

        mapped_params: Final = image_edit_provider_config.map_openai_params(
            image_edit_optional_params=cast(ImageEditOptionalRequestParams, filtered_optional_params),
            model=model,
            drop_params=should_drop,
        )

        return mapped_params

    @staticmethod
    def get_requested_image_edit_optional_param(
        params: Mapping[str, object],
        provider_supported_params: Collection[str] = (),
    ) -> ImageEditOptionalRequestParams:
        """
        Filter parameters to only include those defined in ImageEditOptionalRequestParams.

        Args:
            params: Dictionary of parameters to filter

        Returns:
            ImageEditOptionalRequestParams instance with only the valid parameters
        """
        valid_keys: Final = frozenset(get_type_hints(ImageEditOptionalRequestParams)) | frozenset(
            provider_supported_params
        )
        filtered_params: Final = {k: v for k, v in params.items() if k in valid_keys and v is not None}
        return cast(ImageEditOptionalRequestParams, filtered_params)

    @staticmethod
    def get_image_content_type(image_data: Any) -> str:
        """
        Detect the content type of image data using existing LiteLLM utils.

        Args:
            image_data: Can be BytesIO, bytes, BufferedReader, or other file-like objects

        Returns:
            The MIME type string (e.g., "image/png", "image/jpeg")
        """
        try:
            # Extract bytes for content type detection
            if isinstance(image_data, BytesIO):
                # Save current position
                current_pos = image_data.tell()
                image_data.seek(0)
                bytes_data = image_data.read(100)  # First 100 bytes are enough for detection
                # Restore position
                image_data.seek(current_pos)
            elif isinstance(image_data, BufferedReader):
                # Save current position
                current_pos = image_data.tell()
                image_data.seek(0)
                bytes_data = image_data.read(100)
                # Restore position
                image_data.seek(current_pos)
            elif isinstance(image_data, bytes):
                bytes_data = image_data[:100]
            else:
                # For other types, try to read if possible
                if hasattr(image_data, "read"):
                    current_pos = getattr(image_data, "tell", lambda: 0)()
                    if hasattr(image_data, "seek"):
                        image_data.seek(0)
                    bytes_data = image_data.read(100)
                    if hasattr(image_data, "seek"):
                        image_data.seek(current_pos)
                else:
                    return FILE_MIME_TYPES[FileType.PNG]  # Default fallback

            # Use the existing get_image_type function to detect image type
            image_type_str: Final = get_image_type(bytes_data)

            if image_type_str is None:
                return FILE_MIME_TYPES[FileType.PNG]  # Default if detection fails

            # Map detected type string to FileType enum and get MIME type
            type_mapping: Final = {
                "png": FileType.PNG,
                "jpeg": FileType.JPEG,
                "gif": FileType.GIF,
                "webp": FileType.WEBP,
                "heic": FileType.HEIC,
            }

            file_type: Final = type_mapping.get(image_type_str)
            if file_type is None:
                return FILE_MIME_TYPES[FileType.PNG]  # Default to PNG if unknown

            return FILE_MIME_TYPES[file_type]

        except Exception:
            # If anything goes wrong, default to PNG
            return FILE_MIME_TYPES[FileType.PNG]


@runtime_checkable
class _SeekableBinaryReader(Protocol):
    def tell(self) -> int: ...

    def seek(self, offset: int) -> int: ...

    def read(self) -> bytes: ...


def _read_image_bytes(image: object) -> bytes:
    if isinstance(image, bytes):
        return image
    if isinstance(image, tuple):
        return _read_image_bytes(image[1])
    if isinstance(image, os.PathLike):
        return Path(image).read_bytes()
    if isinstance(image, _SeekableBinaryReader):
        position: Final = image.tell()
        image.seek(0)
        data: Final = image.read()
        image.seek(position)
        return data
    raise ValueError(f"Unsupported image type for image edit: {type(image).__name__}")


def image_to_data_url(image: object) -> str:
    if isinstance(image, str):
        return image
    image_bytes: Final = _read_image_bytes(image)
    mime_type: Final = ImageEditRequestUtils.get_image_content_type(image_bytes)
    return f"data:{mime_type};base64,{base64.b64encode(image_bytes).decode('utf-8')}"
