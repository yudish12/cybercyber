"""Provider / exporter factory + the Baggage span processor."""

import queue
import threading
import time
import weakref
from collections import OrderedDict
from collections.abc import Callable, Iterable, Iterator, Mapping, Sequence
from hashlib import sha256
from types import MappingProxyType
from typing import TYPE_CHECKING, Final, Literal, TypeAlias

from opentelemetry import _logs, baggage, metrics, trace
from opentelemetry._logs import Logger, LoggerProvider, NoOpLoggerProvider
from opentelemetry.context import Context
from opentelemetry.metrics import MeterProvider, NoOpMeterProvider
from opentelemetry.sdk._logs import LoggerProvider as SDKLoggerProvider
from opentelemetry.sdk._logs.export import (
    BatchLogRecordProcessor,
    ConsoleLogExporter,
    InMemoryLogExporter,
    LogExporter,
    SimpleLogRecordProcessor,
)
from opentelemetry.sdk.metrics import MeterProvider as SDKMeterProvider
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import Event, ReadableSpan, SpanProcessor, TracerProvider
from opentelemetry.sdk.trace import Span as SDKSpan
from opentelemetry.sdk.trace.export import (
    BatchSpanProcessor,
    ConsoleSpanExporter,
    SimpleSpanProcessor,
    SpanExporter,
)
from opentelemetry.sdk.trace.export.in_memory_span_exporter import (
    InMemorySpanExporter,
)
from opentelemetry.sdk.trace.sampling import Decision, Sampler, SamplingResult
from opentelemetry.trace import Link, Span, SpanContext, SpanKind, Status, StatusCode, Tracer, TraceState
from opentelemetry.util.re import parse_env_headers
from opentelemetry.util.types import Attributes, AttributeValue

from litellm._logging import verbose_logger
from litellm._version import version as litellm_version
from litellm.integrations.otel.mappers.langfuse import (
    LANGFUSE_OBSERVATION_INPUT,
    LANGFUSE_OBSERVATION_OUTPUT,
    LANGFUSE_REQUEST_METADATA_ATTRIBUTES,
    LANGFUSE_TRACE_NAME,
    LangfuseMapper,
)
from litellm.integrations.otel.model.config import (
    CaptureMessageContent,
    ExporterOwner,
    ExporterSpec,
    OpenTelemetryV2Config,
    capture_message_content_from_env,
    captures_span_content,
    is_unconfigured_placeholder,
)
from litellm.integrations.otel.model.semconv import (
    DB,
    MCP,
    Error,
    ExceptionEvent,
    GenAI,
    LiteLLM,
    LiteLLMError,
    Server,
)
from litellm.integrations.otel.model.spans import LiteLLMSpanKind
from litellm.integrations.otel.plumbing.context import (
    request_destinations,
    request_traces_excluded,
    suppressed_backends,
)
from litellm.integrations.otel.plumbing.otlp_tls import resolve_otlp_http_tls

if TYPE_CHECKING:
    from opentelemetry.metrics import Meter
    from opentelemetry.sdk.metrics.export import MetricReader

    from litellm.integrations.otel.model.destination import OtelDestination
    from litellm.types.utils import OtelSpanScope

_SPAN_KIND_BY_ROLE_KIND: Final[dict[LiteLLMSpanKind, SpanKind]] = {
    LiteLLMSpanKind.SERVER: SpanKind.SERVER,
    LiteLLMSpanKind.CLIENT: SpanKind.CLIENT,
    LiteLLMSpanKind.INTERNAL: SpanKind.INTERNAL,
    LiteLLMSpanKind.PRODUCER: SpanKind.PRODUCER,
    LiteLLMSpanKind.CONSUMER: SpanKind.CONSUMER,
}


def to_otel_span_kind(kind: LiteLLMSpanKind) -> SpanKind:
    return _SPAN_KIND_BY_ROLE_KIND[kind]


# Custom exporter factories keyed by ``ExporterSpec.kind``. A preset registers
# one here when its destination needs construction logic the built-in kinds
# can't express — e.g. an exporter that fetches an auth token lazily on its
# first export (off the event loop) instead of blocking at config-build time.
# Keeping the registry here lets this module stay vendor-agnostic: the factory
# lives with the integration that needs it.
_EXPORTER_FACTORIES: Final[dict[str, Callable[[ExporterSpec], SpanExporter]]] = {}


def register_exporter_factory(kind: str, factory: Callable[[ExporterSpec], SpanExporter]) -> None:
    """Register a custom exporter ``factory`` for the exporter ``kind``."""
    _EXPORTER_FACTORIES[kind.lower()] = factory


class LiteLLMBaggageSpanProcessor(SpanProcessor):
    """Stamps an allowlisted set of Baggage entries onto every span at start."""

    def __init__(
        self,
        allowed_keys: Iterable[str],
        allowed_prefixes: tuple[str, ...] = (LiteLLM.METADATA_PREFIX,),
    ) -> None:
        self._allowed_keys = frozenset(allowed_keys)
        self._allowed_prefixes = tuple(allowed_prefixes)

    def _is_allowed(self, key: str) -> bool:
        return key in self._allowed_keys or any(key.startswith(prefix) for prefix in self._allowed_prefixes)

    def on_start(self, span: Span, parent_context: Context | None = None) -> None:
        for key, value in baggage.get_all(parent_context).items():
            if self._is_allowed(key) and isinstance(value, (str, bool, int, float)):
                span.set_attribute(key, value)

    def on_end(self, span: ReadableSpan) -> None:  # noqa: D401 - no-op
        return None

    def shutdown(self) -> None:
        return None

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        return True


def _otlp_traces_endpoint(endpoint: str | None) -> str | None:
    """Point an OTLP/HTTP base endpoint at the ``/v1/traces`` signal path.

    ``OTEL_EXPORTER_OTLP_ENDPOINT`` is a base URL (e.g. ``http://host:4318``).
    The OTLP/HTTP exporter only appends the ``/v1/traces`` path when it reads
    that env var itself; when an endpoint is passed explicitly it is used
    verbatim, so a base URL would POST to the root and the collector returns
    404. Append the signal path here (leaving an already-correct path intact).
    """
    if not endpoint:
        return endpoint
    endpoint = endpoint.rstrip("/")
    # Splunk Observability uses ``/v2/trace/otlp``; never rewrite it.
    if endpoint.endswith("/v1/traces") or "/v2/trace/otlp" in endpoint:
        return endpoint
    for other_signal in ("/v1/logs", "/v1/metrics"):
        if endpoint.endswith(other_signal):
            return endpoint[: -len(other_signal)] + "/v1/traces"
    return endpoint + "/v1/traces"


def parse_headers(raw: str | None) -> dict[str, str]:
    """Parse an OTLP ``"k=v,k=v"`` header string into a dict.

    ``OTEL_EXPORTER_OTLP_HEADERS`` is W3C Baggage encoded per the OTLP spec, so
    values are percent-decoded: a vendor that documents
    ``Authorization=Basic%20<token>`` (Grafana Cloud does, because a bare space
    is not representable there) has to reach the exporter as ``Basic <token>``,
    not with a literal ``%20`` that the backend rejects as malformed. The SDK's
    own parser is used so litellm decodes exactly what the OTLP exporters do
    when they read the env var themselves; ``liberal`` keeps values that are not
    percent-encoded (``Authorization=Bearer <token>``) working unchanged.
    """
    if not raw:
        return {}
    return dict(parse_env_headers(raw, liberal=True))


_IN_MEMORY_KINDS: Final = ("in_memory", "inmemory", "memory")
_OTLP_HTTP_JSON_KINDS: Final = ("http/json",)
_OTLP_HTTP_KINDS: Final = ("otlp_http", "http", "http/protobuf", *_OTLP_HTTP_JSON_KINDS)
_OTLP_GRPC_KINDS: Final = ("otlp_grpc", "grpc")


def exporter_transport(kind: str) -> Literal["http", "grpc", "headerless"]:
    """How an exporter of this ``kind`` carries credentials, per ``_exporter_from_spec``.

    ``http``/``grpc`` exporters (and any registered factory, which builds an
    OTLP exporter) stamp ``spec.headers``; ``console``, ``in_memory``, and any
    unrecognized kind (which falls back to a header-ignoring console exporter)
    are ``headerless``. Routability decisions must read this rather than a
    denylist, so a typo'd or unavailable kind is not mistaken for OTLP.
    """
    resolved: Final = kind.lower()
    if resolved in _OTLP_HTTP_KINDS or resolved in _EXPORTER_FACTORIES:
        return "http"
    if resolved in _OTLP_GRPC_KINDS:
        return "grpc"
    return "headerless"


def _exporter_from_spec(spec: ExporterSpec) -> SpanExporter:
    kind: Final = (spec.kind or "console").lower()
    factory: Final = _EXPORTER_FACTORIES.get(kind)
    if factory is not None:
        return factory(spec)
    if kind in _IN_MEMORY_KINDS:
        return InMemorySpanExporter()
    if kind in _OTLP_HTTP_JSON_KINDS:
        from litellm.integrations.otel.plumbing.otlp_json import OTLPJsonSpanExporter

        tls: Final = resolve_otlp_http_tls("TRACES")
        return OTLPJsonSpanExporter(
            endpoint=spec.traces_endpoint or _otlp_traces_endpoint(spec.endpoint),
            headers=parse_headers(spec.headers),
            certificate_file=tls.certificate_file,
            session=tls.session,
        )
    if kind in _OTLP_HTTP_KINDS:
        from opentelemetry.exporter.otlp.proto.http.trace_exporter import (
            OTLPSpanExporter as HTTPExporter,
        )

        http_tls: Final = resolve_otlp_http_tls("TRACES")
        return HTTPExporter(
            endpoint=spec.traces_endpoint or _otlp_traces_endpoint(spec.endpoint),
            headers=parse_headers(spec.headers),
            certificate_file=http_tls.certificate_file,
            session=http_tls.session,
        )
    if kind in _OTLP_GRPC_KINDS:
        from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import (
            OTLPSpanExporter as GRPCExporter,
        )

        return GRPCExporter(endpoint=spec.endpoint, headers=parse_headers(spec.headers))
    return ConsoleSpanExporter()


def _processor_for(exporter: SpanExporter, use_simple: bool | None) -> SpanProcessor:
    """Pick a Simple or Batch span processor for ``exporter``.

    When ``use_simple`` is unset, default to Simple for console and in-memory
    exporters (spans export synchronously, which tests rely on) and Batch for
    everything else (the right export semantics for production).
    """
    if use_simple is None:
        use_simple = isinstance(exporter, (ConsoleSpanExporter, InMemorySpanExporter))
    return SimpleSpanProcessor(exporter) if use_simple else BatchSpanProcessor(exporter)


#: Distinct tenant destinations whose exporters stay alive. Each holds a connection
#: pool and a batch thread, so the cache is bounded and evicts least-recently-used.
_MAX_CACHED_DESTINATION_PROCESSORS: Final = 32

#: Workers closing shed destination processors, bounding the threads a tenant can
#: create by cycling its destination config.
_DRAIN_WORKERS: Final = 2

#: Shed processors waiting to be closed before the fan-out stops building new ones.
#: Each still owns a batch thread until its close returns, and a collector that never
#: answers makes every close take the exporter's full timeout, so past this many the
#: operator's exporter keeps the span instead (see ``deliverable``).
_MAX_PENDING_DRAINS: Final = 64

#: How long ``shutdown`` waits for spans already being forwarded, so teardown closes
#: no processor under one. Bounded: an exporter that never returns must not hold the
#: proxy open.
_SHUTDOWN_DRAIN_SECONDS: Final = 5.0

#: An exporter's account: its normalized endpoint and the credentials it presents.
_SinkKey = tuple[str, tuple[tuple[str, str], ...]]

#: Header names that spell one credential two ways. Arize's operator exporter sends
#: ``space_id`` where a tenant destination sends ``arize-space-id``.
_CREDENTIAL_ALIASES: Final = MappingProxyType({"arize_space_id": "space_id"})


class _DrainPool:
    """Closes shed destination processors off the span-export path.

    ``shutdown`` flushes over the network and is reached from ``on_end``, so closing
    one inline would let a single unreachable tenant collector stall every other
    tenant's spans behind it. A fixed set of workers rather than a thread per
    processor means a tenant cycling its destination config cannot spawn threads as
    fast as it can send requests; slow shutdowns queue behind each other.

    The workers are daemons and belong to the fan-out that sheds the processors, so
    neither an unreachable collector nor a lazily built process-wide singleton can
    hold the proxy open on the way down.
    """

    def __init__(
        self,
        workers: int = _DRAIN_WORKERS,
        pending: "queue.Queue[SpanProcessor | None] | None" = None,
        capacity: int = _MAX_PENDING_DRAINS,
    ) -> None:
        self._workers: Final = workers
        self._capacity: Final = capacity
        self._lock: Final = threading.Lock()
        self._closed = False
        self._backlog = 0  # guarded by ``_lock``: submitted processors whose close has not returned
        self._pending: Final[queue.Queue[SpanProcessor | None]] = pending if pending is not None else queue.Queue()
        self._threads: Final = tuple(
            threading.Thread(target=self._drain_until_closed, daemon=True, name="litellm-otel-destination-drain")
            for _ in range(workers)
        )
        for worker in self._threads:
            worker.start()

    def submit(self, processor: SpanProcessor) -> None:
        """Queue ``processor`` for closing, or hand it off once the pool is retired.

        The check and the put share one lock. Reading a closed flag on its own leaves
        room for :meth:`close` to run in between, and the processor would land behind
        the sentinels every worker has already exited on.

        Past close there is no worker left to take it, and the caller is whichever
        thread just ended a span, so closing it inline would park that thread on a
        network flush the shutdown deadline has already stopped waiting for. The extra
        thread is bounded by the same close: the fan-out stops handing processors out
        at that point, so only the ones already exporting when it happened arrive here.
        """
        with self._lock:
            if not self._closed:
                self._backlog += 1
                self._pending.put(processor)
                return
        threading.Thread(
            target=_shutdown_quietly,
            args=(processor,),
            daemon=True,
            name="litellm-otel-destination-drain-straggler",
        ).start()

    def saturated(self) -> bool:
        """Whether enough closes are outstanding that building another processor must wait.

        The workers close in order and each close blocks for as long as its exporter
        does, so a collector that stopped answering would otherwise turn every new
        destination into one more batch thread parked behind them, for as long as the
        tenants keep rotating. Holding the count here rather than reading the queue
        keeps the two processors a worker is mid-close on in the total.
        """
        with self._lock:
            return self._backlog >= self._capacity

    def close(self, timeout: float | None = None) -> None:
        """Retire the workers once they have closed everything already queued.

        A proxy that rebuilds its telemetry builds another fan-out, so workers that
        outlive the one that started them are two more threads per reload, forever.

        ``timeout`` bounds how long the caller waits for that draining to finish. The
        workers are daemons, so whatever is still flushing when it expires is dropped
        by the interpreter rather than holding it open.
        """
        with self._lock:
            if self._closed:
                return
            self._closed = True
            for _ in range(self._workers):
                self._pending.put(None)
        if timeout is None:
            return
        deadline: Final = time.monotonic() + timeout
        for worker in self._threads:
            worker.join(timeout=max(0.0, deadline - time.monotonic()))

    def _drain_until_closed(self) -> None:
        while True:
            processor: SpanProcessor | None = self._pending.get()
            if processor is None:
                return
            _shutdown_quietly(processor)
            with self._lock:
                self._backlog -= 1


LITELLM_TRACER_NAME: Final = "litellm"
_NO_ATTRIBUTES: Final[Mapping[str, AttributeValue]] = MappingProxyType({})
_DB_SYSTEM_KEYS: Final = frozenset({DB.SYSTEM_NAME, DB.SYSTEM_LEGACY})
# Keys on a database span that describe the proxy's own datastore: its host, its
# port, and its schema.
_DATASTORE_ENDPOINT_KEYS: Final = frozenset({Server.ADDRESS, Server.PORT, DB.NAMESPACE})
# A span carrying one of these describes the tenant's own call (the model call, the
# MCP call, the guardrail), so its error text is theirs to see. Every other span is
# the proxy's own work, whose error text names the operator's infrastructure.
_TENANT_OWNED_KEYS: Final = frozenset({GenAI.OPERATION_NAME, MCP.METHOD_NAME, LiteLLM.GUARDRAIL_NAME})
_PROXY_ERROR_TEXT_KEYS: Final = frozenset({Error.MESSAGE, Error.MESSAGE_LEGACY})
# A guardrail that never answered carries the exception it raised as its response,
# which names the operator's guardrail endpoint. The second spelling is the legacy
# status the request-level logger still maps.
_GUARDRAIL_UNREACHABLE_STATUSES: Final = frozenset({"guardrail_failed_to_respond", "failure"})
# Attribute prefixes the FastAPI instrumentor uses for headers the operator opted to
# capture (``OTEL_INSTRUMENTATION_HTTP_CAPTURE_HEADERS_SERVER_*``). The request
# side carries the caller's bearer token verbatim.
_CAPTURED_HEADER_PREFIXES: Final = ("http.request.header.", "http.response.header.")
# The instrumentor stamps the request URL on the server span with its query string,
# under the old convention and the new one, and litellm accepts a virtual key as a
# ``?key=`` query parameter.
_URL_KEYS: Final = frozenset({"http.url", "http.target", "url.full"})
_URL_QUERY_KEY: Final = "url.query"
# Prompt and response content, in every vocabulary the mappers write it in once the
# global capture policy collects it: GenAI semconv (MCP tool-call arguments and results
# included), Langfuse, OpenInference's blobs and per-index messages, Langtrace, Weave.
_MESSAGE_CONTENT_KEYS: Final = frozenset(
    {
        GenAI.INPUT_MESSAGES,
        GenAI.OUTPUT_MESSAGES,
        GenAI.SYSTEM_INSTRUCTIONS,
        GenAI.TOOL_CALL_ARGUMENTS,
        GenAI.TOOL_CALL_RESULT,
        LANGFUSE_OBSERVATION_INPUT,
        LANGFUSE_OBSERVATION_OUTPUT,
        "input.value",
        "output.value",
        "llm.prompts",
        "llm.completions",
        "weave.output",
    }
)
_INDEXED_MESSAGE_PREFIXES: Final = ("llm.input_messages.", "llm.output_messages.")


class _SpanView(ReadableSpan):
    """A ``ReadableSpan`` view for one exporter, leaving the span every other exporter sees alone."""

    def __init__(
        self,
        inner: ReadableSpan,
        resource: Resource,
        attributes: Attributes,
        events: Sequence[Event],
        status: Status,
        parent: SpanContext | None,
    ) -> None:
        super().__init__(
            name=inner.name,
            context=inner.context,
            parent=parent,
            resource=resource,
            attributes=attributes,
            events=events,
            links=inner.links,
            kind=inner.kind,
            status=status,
            start_time=inner.start_time,
            end_time=inner.end_time,
            instrumentation_scope=inner.instrumentation_scope,
        )


def _is_message_content(key: str) -> bool:
    return key in _MESSAGE_CONTENT_KEYS or key.startswith(_INDEXED_MESSAGE_PREFIXES)


def without_message_content(span: ReadableSpan) -> ReadableSpan:
    """``span`` without its prompt and response content, everything else left as it was."""
    attributes: Final = span.attributes or _NO_ATTRIBUTES
    if not any(_is_message_content(key) for key in attributes):
        return span
    kept: Final = MappingProxyType({key: value for key, value in attributes.items() if not _is_message_content(key)})
    return _SpanView(span, span.resource, kept, span.events, span.status, parent=span.parent)


class _CountedSpanView(_SpanView):
    """A ``_SpanView`` of ``inner`` with other attributes that reports the dropped counts ``inner`` reports."""

    def __init__(self, inner: ReadableSpan, attributes: Attributes) -> None:
        super().__init__(inner, inner.resource, attributes, inner.events, inner.status, parent=inner.parent)
        self._dropped_counts: Final = (inner.dropped_attributes, inner.dropped_events, inner.dropped_links)

    @property
    def dropped_attributes(self) -> int:
        return self._dropped_counts[0]

    @property
    def dropped_events(self) -> int:
        return self._dropped_counts[1]

    @property
    def dropped_links(self) -> int:
        return self._dropped_counts[2]


def _is_litellm_span(span: ReadableSpan) -> bool:
    """Whether LiteLLM's own tracer wrote ``span``, rather than application or instrumentation code."""
    scope: Final = span.instrumentation_scope
    return scope is not None and scope.name == LITELLM_TRACER_NAME


def without_destination_langfuse_attributes(span: ReadableSpan, langfuse_mapped: bool) -> ReadableSpan:
    """``span`` without the Langfuse attributes only a Langfuse destination asked for.

    That is the request metadata the Langfuse mapper writes and, on a model call written by
    a logger whose own mappers leave the Langfuse vocabulary out (``langfuse_mapped`` off),
    every Langfuse attribute, since that logger wrote them for a key's or team's Langfuse
    destination alone. Only LiteLLM's own spans lose them: any other span keeps every key
    its own code set.
    """
    attributes: Final = span.attributes or _NO_ATTRIBUTES
    dropped: Final = (
        LANGFUSE_REQUEST_METADATA_ATTRIBUTES
        if langfuse_mapped or not is_llm_call_span(span)
        else LangfuseMapper.LLM_CALL_ATTRIBUTES
    )
    if not (_is_litellm_span(span) and any(key in dropped for key in attributes)):
        return span
    return _CountedSpanView(
        span, MappingProxyType({key: value for key, value in attributes.items() if key not in dropped})
    )


def _is_database_span(attributes: Mapping[str, AttributeValue]) -> bool:
    return any(key in attributes for key in _DB_SYSTEM_KEYS)


def _is_excluded_database_span(attributes: Mapping[str, AttributeValue], excluded: frozenset[str]) -> bool:
    if not excluded:
        return False
    system: Final = attributes.get(DB.SYSTEM_NAME) or attributes.get(DB.SYSTEM_LEGACY)
    return isinstance(system, str) and system in excluded


def _is_tenant_owned_span(attributes: Mapping[str, AttributeValue]) -> bool:
    return any(key in attributes for key in _TENANT_OWNED_KEYS)


def is_llm_call_span(span: ReadableSpan) -> bool:
    """Whether ``span`` is the model call itself.

    The GenAI mapper stamps ``gen_ai.operation.name`` on the model call and on the
    MCP tool call, so the MCP method name tells the two apart. Guardrail, request
    root, auth and database spans never carry the operation name; ``gen_ai.request.model``
    would not do, since baggage promotes it onto every child span.
    """
    attributes: Final = span.attributes or _NO_ATTRIBUTES
    return GenAI.OPERATION_NAME in attributes and MCP.METHOD_NAME not in attributes


#: Request trees held back for a sampled destination until the last span of the request
#: still open ends, the verdicts kept for the spans that start after that (a post-call
#: database write), the spans in flight per request, and the request each open span
#: belongs to. All bounded, so a span that never ends, or a flood of requests, cannot
#: hold spans for ever: the oldest tree is decided on what it has.
_MAX_PENDING_TREES: Final = 1024
_MAX_PENDING_SPANS_PER_TREE: Final = 512
_MAX_REMEMBERED_VERDICTS: Final = 4096
_MAX_OPEN_REQUESTS: Final = 16384


class _PendingTree:
    """The spans of one request held for its sampled destinations, and whether any
    span of the tree has failed so far."""

    __slots__ = ("failed", "held")

    def __init__(self) -> None:
        self.failed = False
        self.held: list[tuple[ReadableSpan, OtelDestination]] = []  # mutable-ok: bounded per tree


def _is_sampled(destination: "OtelDestination") -> bool:
    return destination.success_sampling_rate is not None or destination.error_sampling_rate is not None


#: A request is its trace id and the id of its root, the span of it whose parent is
#: remote or missing. Calls sharing a caller's trace are separate requests, each decided
#: on its own outcome.
_RequestKey: TypeAlias = tuple[int, int]

#: A verdict is one request's keep or drop for one destination at its rates: the exporter
#: ``cache_key`` leaves the rates out, so two destinations sharing an exporter with
#: different rates would otherwise share one verdict.
_VerdictKey: TypeAlias = tuple[int, int, object, float | None, float | None]


def _verdict_key(request: _RequestKey, destination: "OtelDestination") -> _VerdictKey:
    return (*request, destination.cache_key(), destination.success_sampling_rate, destination.error_sampling_rate)


def _keeps_tree(destination: "OtelDestination", failed: bool, trace_id: int) -> bool:
    """Whether the destination's rate keeps a request tree of ``trace_id``: a tree with
    a failed span answers to ``arize_error_sampling_rate``, the rest to
    ``arize_success_sampling_rate``, an unset rate keeps everything and ``0.0`` keeps
    nothing.

    The first eight bytes of a SHA-256 of the trace id are read against the rate, so
    every process deciding a request of the trace with the same outcome reaches the same
    verdict."""
    rate: Final = destination.error_sampling_rate if failed else destination.success_sampling_rate
    if rate is None:
        return True
    digest: Final = sha256(trace_id.to_bytes(16, "big")).digest()
    return int.from_bytes(digest[:8], "big") < round(rate * 2**64)


def _in_scope(span: ReadableSpan, scope: "OtelSpanScope") -> bool:
    return scope == "full" or is_llm_call_span(span)


def _scoped(span: ReadableSpan, scope: "OtelSpanScope") -> ReadableSpan:
    """Under ``llm_only`` the model call is the only span the exporter gets, so it goes out as the
    trace's root (its parent is the request span that is held back) and, unless the caller named the
    trace, its own name doubles as ``langfuse.trace.name`` so Langfuse does not show "Unnamed trace"."""
    if scope == "full":
        return span
    attributes: Final = span.attributes or _NO_ATTRIBUTES
    named: Final = (
        attributes
        if LANGFUSE_TRACE_NAME in attributes
        else MappingProxyType({**attributes, LANGFUSE_TRACE_NAME: span.name})
    )
    if span.parent is None and named is attributes:
        return span
    return _SpanView(span, span.resource, named, span.events, span.status, parent=None)


def _guardrail_unreachable(attributes: Mapping[str, AttributeValue]) -> bool:
    return attributes.get(LiteLLM.GUARDRAIL_STATUS) in _GUARDRAIL_UNREACHABLE_STATUSES


def _tenant_visible(key: str, database: bool, owned: bool, unreachable_guardrail: bool) -> bool:
    if key.startswith(_CAPTURED_HEADER_PREFIXES) or key in (LiteLLMError.STACK_TRACE, _URL_QUERY_KEY):
        return False
    if database and key in _DATASTORE_ENDPOINT_KEYS:
        return False
    if unreachable_guardrail and key == LiteLLM.GUARDRAIL_RESPONSE:
        return False
    return owned or key not in _PROXY_ERROR_TEXT_KEYS


def _without_query(key: str, value: AttributeValue) -> AttributeValue:
    if key not in _URL_KEYS or not isinstance(value, str):
        return value
    return value.partition("?")[0]


def _same_attributes(kept: Mapping[str, AttributeValue], attributes: Mapping[str, AttributeValue]) -> bool:
    return len(kept) == len(attributes) and all(kept[key] is value for key, value in attributes.items())


def _without_stack_trace(event: Event) -> Event:
    attributes: Final = event.attributes or _NO_ATTRIBUTES
    if ExceptionEvent.STACKTRACE not in attributes:
        return event
    return Event(
        name=event.name,
        attributes=MappingProxyType(
            {key: value for key, value in attributes.items() if key != ExceptionEvent.STACKTRACE}
        ),
        timestamp=event.timestamp,
    )


def _tenant_resource(resource: Resource, defaults: Mapping[str, str], extra: Mapping[str, str]) -> Resource:
    """``resource`` over the backend's ``defaults``, under the destination's ``extra``."""
    filled: Final = Resource(defaults).merge(resource) if defaults else resource
    return filled.merge(Resource(extra)) if extra else filled


def _for_destination(
    span: ReadableSpan,
    destination: "OtelDestination",
    default_capture: str,
    langfuse_mapped: bool,
) -> ReadableSpan:
    """The view of ``span`` a tenant destination receives.

    A span the tenant's own call produced keeps its error text. Every other span is
    the proxy's own work (the request root, auth, the database), and its error text,
    its events and its status description come off, since a Prisma failure there
    spells out the operator's Postgres endpoint. A database span loses that endpoint
    too, and a guardrail that failed to respond loses its response text, which is the
    exception it raised and names the operator's guardrail endpoint. Stack traces walk
    the operator's install and come off every span, as do the headers the operator
    captures on the server span, whose request side holds the caller's bearer token,
    and the query string of the request URL, which can hold the same key. A
    destination whose effective setting disables span content loses the prompt and
    response content too, and a destination for any backend but Langfuse loses the
    Langfuse attributes only a Langfuse destination asked for (see
    :func:`without_destination_langfuse_attributes`). The span itself stays, so the
    tenant still gets the whole trace tree.
    """
    extra: Final = destination.resource_attributes
    defaults: Final = destination.resource_defaults
    source: Final = (
        span
        if destination.callback_name == ExporterOwner.LANGFUSE_OTEL
        else without_destination_langfuse_attributes(span, langfuse_mapped)
    )
    attributes: Final = source.attributes or _NO_ATTRIBUTES
    database: Final = _is_database_span(attributes)
    owned: Final = _is_tenant_owned_span(attributes)
    unreachable: Final = _guardrail_unreachable(attributes)
    redacted: Final = not destination.captures_content(default_capture)
    kept: Final = MappingProxyType(
        {
            key: _without_query(key, value)
            for key, value in attributes.items()
            if _tenant_visible(key, database, owned, unreachable) and not (redacted and _is_message_content(key))
        }
    )
    recorded: Final = source.events
    events: Final = tuple(_without_stack_trace(event) for event in recorded) if owned else ()
    unchanged: Final = owned and _same_attributes(kept, attributes) and all(a is b for a, b in zip(events, recorded))
    if not extra and not defaults and unchanged:
        return source
    resource: Final = _tenant_resource(source.resource, defaults, extra)
    status: Final = source.status if owned else Status(source.status.status_code)
    return _SpanView(source, resource, kept, events, status, parent=source.parent)


class TenantFanOutSpanProcessor(SpanProcessor):
    """Export every finished span to each destination this request resolved.

    Destinations ride a request-scoped ``ContextVar`` set during auth, so concurrent
    requests stay isolated. The forwarded view keeps the original trace and parent
    ids, so the tenant gets the same tree the operator would have received.

    Exactly one provider carries this processor, the one published as the OTel global
    (see :func:`attach_tenant_fan_out`). That provider is the only one every span
    passes through: the FastAPI server span, the auth span and the post-call database
    spans are emitted on the global, while a second v2 logger's provider sees only
    that logger's own gen-AI span. Attaching the fan-out per logger would hand a
    tenant a one-span trace whenever its backend is not the global one, and two
    copies of the model call whenever it is.
    """

    def __init__(
        self,
        processor_factory: 'Callable[["OtelDestination"], SpanProcessor | None] | None' = None,
        shutdown_drain_seconds: float = _SHUTDOWN_DRAIN_SECONDS,
        operator_sinks: 'Mapping[_SinkKey, "OtelSpanScope"]' = MappingProxyType({}),
        excluded_db_systems: frozenset[str] = frozenset(),
        default_capture: str = CaptureMessageContent.NO_CONTENT,
        default_capture_by_backend: Mapping[str, str] = MappingProxyType({}),
        pending_drains: int = _MAX_PENDING_DRAINS,
        drain_pool: _DrainPool | None = None,
        langfuse_mapped: bool = True,
    ) -> None:
        self._operator_sinks: Final = operator_sinks
        self._langfuse_mapped: Final = langfuse_mapped
        self._excluded_db_systems: Final = excluded_db_systems
        self._default_capture: Final = default_capture
        self._default_capture_by_backend: Final = default_capture_by_backend
        self._drain_seconds: Final = shutdown_drain_seconds
        self._lock: Final = threading.Condition()
        self._closed = False  # guarded by ``_lock``: an unlocked read races the teardown it gates
        self._draining = False  # guarded by ``_lock``: shutdown is flushing, nothing is held any more
        self._build: Final = processor_factory if processor_factory is not None else _destination_processor
        self._processors: OrderedDict[object, SpanProcessor] = OrderedDict()  # mutable-ok: bounded LRU
        self._retired: OrderedDict[int, SpanProcessor] = OrderedDict()  # mutable-ok: drains as exports finish
        self._exporting: dict[int, int] = {}  # mutable-ok: per-processor in-flight export count
        self._pending: OrderedDict[_RequestKey, _PendingTree] = OrderedDict()  # mutable-ok: bounded, by request
        self._open: OrderedDict[_RequestKey, set[int]] = OrderedDict()  # mutable-ok: bounded, open span ids by request
        self._roots: dict[int, _RequestKey] = {}  # mutable-ok: holds only the spans ``_open`` holds, request by span id
        self._span_roots: weakref.WeakKeyDictionary[SDKSpan, int] = weakref.WeakKeyDictionary()
        self._verdicts: OrderedDict[_VerdictKey, bool] = OrderedDict()  # mutable-ok: bounded LRU
        self._drain: Final = drain_pool if drain_pool is not None else _DrainPool(capacity=pending_drains)

    def on_start(self, span: SDKSpan, parent_context: Context | None = None) -> None:
        context: Final = span.context
        with self._lock:
            request: Final = self._request_of(span, trace.get_current_span(parent_context))
            if context is not None:
                self._span_roots[span] = request[1]
                self._roots[context.span_id] = request
                self._open.setdefault(request, set()).add(context.span_id)
            while len(self._open) > _MAX_OPEN_REQUESTS:
                for forgotten in self._open.popitem(last=False)[1]:
                    self._roots.pop(forgotten, None)

    def on_end(self, span: ReadableSpan) -> None:
        suppressed: Final = suppressed_backends()
        attributes: Final = span.attributes or _NO_ATTRIBUTES
        with self._lock:
            request: Final = self._request_of(span)
            if span.context is not None:
                self._roots.pop(span.context.span_id, None)
        failed: Final = span.status.status_code is StatusCode.ERROR
        for destination in request_destinations():
            if (
                self._operator_already_writes(span, destination, suppressed)
                or not _in_scope(span, destination.span_scope)
                or _is_excluded_database_span(
                    attributes,
                    self._excluded_db_systems
                    if destination.excluded_db_systems is None
                    else destination.excluded_db_systems,
                )
            ):
                continue
            if not _is_sampled(destination):
                self._forward(span, destination)
                continue
            for held_span, held_destination in self._route(request, span, destination, failed):
                self._forward(held_span, held_destination)
        for held_span, held_destination in self._settle(request, span, failed):
            self._forward(held_span, held_destination)

    def _request_of(self, span: ReadableSpan, parent_span: Span | None = None) -> _RequestKey:
        """The request ``span`` belongs to, read under ``_lock``: the request recorded while
        it is open, else the span itself when its parent is remote or missing, else its
        parent's request, recorded while the parent is open or on ``parent_span`` for a
        child starting under a parent that has ended, else the parent itself."""
        context: Final = span.context
        if context is None:
            return (0, 0)
        recorded: Final = self._roots.get(context.span_id)
        if recorded is not None:
            return recorded
        parent: Final = span.parent
        if parent is None or parent.is_remote:
            return (context.trace_id, context.span_id)
        parent_request: Final = self._roots.get(parent.span_id)
        if parent_request is not None:
            return parent_request
        if isinstance(parent_span, SDKSpan):
            return (context.trace_id, self._span_roots.get(parent_span, parent.span_id))
        return (context.trace_id, parent.span_id)

    def _default_capture_for(self, destination: "OtelDestination") -> str:
        backend: Final = destination.callback_name
        return (
            self._default_capture_by_backend.get(backend, self._default_capture) if backend else self._default_capture
        )

    def _forward(self, span: ReadableSpan, destination: "OtelDestination") -> None:
        processor: Final = self._acquire(destination)
        if processor is None:
            return
        try:
            processor.on_end(
                _scoped(
                    _for_destination(span, destination, self._default_capture_for(destination), self._langfuse_mapped),
                    destination.span_scope,
                )
            )
        except Exception as exc:  # noqa: BLE001  # one destination's failure must not cost the others their span
            verbose_logger.debug("OTel V2 fan-out: forwarding to %s failed: %s", destination.endpoint, exc)
        finally:
            self._release(processor)

    def _route(
        self, request: _RequestKey, span: ReadableSpan, destination: "OtelDestination", failed: bool
    ) -> "tuple[tuple[ReadableSpan, OtelDestination], ...]":
        """The spans to forward now for ``span`` on a sampled ``destination``: the span
        itself when its tree's verdict is already known and keeps it, nothing while the
        tree is held for the rest of its request, or what the bounds made the fan-out decide
        early (a tree that outgrew its cap is decided on what it has, and so is the oldest
        tree once too many are waiting, so a span that never ends holds nothing back for
        ever). A failed span marks its tree before any such early decision. Once shutdown
        has started flushing, nothing is held: a span ending then is decided at once,
        since no later flush would reach it.

        The verdict lookup and the hold share one lock acquisition: a tree deciding on
        another thread between the two would leave this span in a fresh tree.
        """
        with self._lock:
            verdict: Final = self._verdicts.get(_verdict_key(request, destination))
            if verdict is not None:
                return ((span, destination),) if verdict else ()
            tree: Final = self._pending.setdefault(request, _PendingTree())
            tree.held.append((span, destination))
            if failed:
                tree.failed = True
            if self._draining or len(tree.held) >= _MAX_PENDING_SPANS_PER_TREE:
                return self._decide_locked(request)
            if len(self._pending) > _MAX_PENDING_TREES:
                oldest: Final = next(iter(self._pending))
                return self._decide_locked(oldest)
            return ()

    def _decide(self, request: _RequestKey) -> "tuple[tuple[ReadableSpan, OtelDestination], ...]":
        with self._lock:
            return self._decide_locked(request)

    def _settle(
        self, request: _RequestKey, span: ReadableSpan, failed: bool
    ) -> "tuple[tuple[ReadableSpan, OtelDestination], ...]":
        """What the request's held tree exports once the span that just ended was the last
        of its request still open. The model-call span ends in the post-call callback,
        after the server span, so a tree is decided when its request goes quiet rather than
        when its root ends, and a model call that fails late still answers to the error
        rate. A request whose starts this fan-out never saw (attached mid-flight, or
        forgotten by the bound) is decided as each of its spans ends.
        """
        with self._lock:
            tree: Final = self._pending.get(request)
            if tree is not None and failed:
                tree.failed = True
            still_open: Final = self._open.pop(request, set())
            if span.context is not None:
                still_open.discard(span.context.span_id)
            if still_open:
                self._open[request] = still_open
                return ()
            return self._decide_locked(request)

    def _decide_locked(self, request: _RequestKey) -> "tuple[tuple[ReadableSpan, OtelDestination], ...]":
        """Decide once per destination for the held tree; the spans the verdicts keep, and
        a verdict remembered for the spans of this request that start later."""
        tree: Final = self._pending.pop(request, None)
        if tree is None:
            return ()
        verdicts: dict[_VerdictKey, bool] = {}  # mutable-ok: one verdict per destination of this tree
        for _, destination in tree.held:
            key = _verdict_key(request, destination)
            if key not in verdicts:
                verdicts[key] = _keeps_tree(destination, tree.failed, request[0])
                self._verdicts[key] = verdicts[key]
        while len(self._verdicts) > _MAX_REMEMBERED_VERDICTS:
            self._verdicts.popitem(last=False)
        return tuple(
            (span, destination) for span, destination in tree.held if verdicts[_verdict_key(request, destination)]
        )

    def _operator_already_writes(
        self, span: ReadableSpan, destination: "OtelDestination", suppressed: frozenset[str]
    ) -> bool:
        """Whether the operator's own exporter is sending this span to the same account.

        Only reachable under ``additive``, where nothing is suppressed: a team that
        names the operator's own project would otherwise have every span written
        there twice, once by the operator's exporter and once by the fan-out. The
        operator's exporter may itself be narrowed to the model calls, in which case
        the rest of the tree is still the fan-out's to deliver.
        """
        sink: Final = _sink_key(destination.endpoint, destination.headers)
        if destination.callback_name in suppressed or sink is None:
            return False
        operator_scope: Final = self._operator_sinks.get(sink)
        return operator_scope is not None and _in_scope(span, operator_scope)

    def shutdown(self) -> None:
        """Close every destination processor, once the spans in flight have landed.

        ``on_end`` runs on whichever thread ends a span and can reach this fan-out
        while the SDK is tearing the provider down, so closing blind would drop a
        trace mid-forward and would hand the next caller a fresh exporter nothing
        will ever close. Refusing new work and then waiting out the in-flight ones
        keeps both from happening. A straggler past the bound is retired instead of
        closed: the thread still exporting it closes it through the drain as soon as
        its export returns, so no span is dropped mid-forward.

        Every close then goes to the drain rather than running here. Closing a
        destination processor flushes it over the network and the SDK joins its own
        worker with no timeout of its own, so one tenant collector that answers but
        never finishes a response would otherwise hold process teardown open for as
        long as it likes. The drain's workers are daemons, and the whole teardown
        shares one deadline.
        """
        with self._lock:
            self._draining = True
            undecided: Final = tuple(self._pending)
        for request in undecided:
            for held_span, held_destination in self._decide(request):
                self._forward(held_span, held_destination)
        deadline: Final = time.monotonic() + self._drain_seconds
        with self._lock:
            self._closed = True
            self._lock.wait_for(lambda: not self._exporting, timeout=self._drain_seconds)
            live: Final = tuple((id(p), p) for p in (*self._processors.values(), *self._retired.values()))
            closing: Final = tuple(p for ident, p in live if ident not in self._exporting)
            self._processors.clear()
            self._retired = OrderedDict((ident, p) for ident, p in live if ident in self._exporting)
        for processor in closing:
            self._drain.submit(processor)
        self._drain.close(timeout=max(0.0, deadline - time.monotonic()))

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        results: Final = tuple(self._flush_one(processor, timeout_millis) for processor in self._snapshot())
        return all(results)

    def _snapshot(self) -> tuple[SpanProcessor, ...]:
        with self._lock:
            return (*self._processors.values(), *self._retired.values())

    @staticmethod
    def _flush_one(processor: SpanProcessor, timeout_millis: int) -> bool:
        try:
            return processor.force_flush(timeout_millis)
        except Exception:  # noqa: BLE001  # one exporter's flush failure must not fail the whole flush
            return False

    def deliverable(self, destinations: Iterable["OtelDestination"]) -> tuple["OtelDestination", ...]:
        """The subset of ``destinations`` this fan-out can actually export to.

        A destination whose exporter will not build (a protocol whose package is not
        installed, a malformed endpoint) has to be dropped before the request anchors
        it, not when its first span ends. By then the operator's own exporter has been
        told to hold that backend's spans back for this request, so dropping there
        loses the span outright instead of leaving it where it would have gone with no
        override at all.
        """
        return tuple(destination for destination in destinations if self._buildable(destination))

    def _buildable(self, destination: "OtelDestination") -> bool:
        """Whether a processor for ``destination`` exists or can be built right now."""
        with self._lock:
            if self._closed:
                return False
            built: Final = self._cached_or_built_locked(destination, anchored=False)
            drained: Final = self._drainable_locked()
            for shed in drained:
                self._drain.submit(shed)
            return built is not None

    def _acquire(self, destination: "OtelDestination") -> SpanProcessor | None:
        """The processor for ``destination``, marked busy until ``_release``.

        The build happens under the same lock that reads the cache, so a cold cache
        met by a burst of concurrent requests yields one exporter rather than one per
        thread with all but the winner shed. Building an exporter opens no connection,
        so the cost of holding the lock is a constructor, once per destination.
        """
        with self._lock:
            if self._closed:
                return None
            processor: Final = self._cached_or_built_locked(destination, anchored=True)
            if processor is None:
                return None
            self._exporting[id(processor)] = self._exporting.get(id(processor), 0) + 1
            drained: Final = self._drainable_locked()
            for shed in drained:
                self._drain.submit(shed)
            return processor

    def _cached_or_built_locked(self, destination: "OtelDestination", *, anchored: bool) -> SpanProcessor | None:
        """The cached processor for ``destination``, or a new one if the drain can take it.

        Every build past the cache cap sheds one processor into the drain, so while the
        shed ones are stuck closing against a collector that stopped answering, a
        destination that is not yet anchored is refused rather than parked behind them:
        ``deliverable`` then leaves its spans with the operator's exporter until the
        drain catches up. One the request already anchored is rebuilt regardless. The
        operator's exporter has stood down for it, so refusing here would drop the span,
        and other tenants' auths can evict it in the meantime, with that eviction being
        what tips the drain over. Eviction holds while the drain is saturated, so such a
        rebuild costs the cache one entry rather than shedding another processor, and
        the total stays at one per destination in flight.
        """
        key: Final = destination.cache_key()
        if (cached := self._processors.get(key)) is not None:
            self._processors.move_to_end(key)
            self._retire_overflow_locked()
            return cached
        if not anchored and self._drain.saturated():
            verbose_logger.debug("OTel V2 fan-out: drain saturated, not building for %s", destination.endpoint)
            return None
        return self._build_locked(destination, key)

    def _build_locked(self, destination: "OtelDestination", key: object) -> SpanProcessor | None:
        built: Final = self._build(destination)
        if built is None:
            return None
        self._processors[key] = built
        self._retire_overflow_locked()
        return built

    def _release(self, processor: SpanProcessor) -> None:
        with self._lock:
            remaining: Final = self._exporting.get(id(processor), 1) - 1
            if remaining > 0:
                self._exporting[id(processor)] = remaining
            else:
                self._exporting.pop(id(processor), None)
                if not self._exporting:
                    self._lock.notify_all()
            drained: Final = self._drainable_locked()
            for retired in drained:
                self._drain.submit(retired)

    def _retire_overflow_locked(self) -> None:
        """Move the LRU processor out of the cache once it is past the cap, drain permitting.

        Eviction is what feeds the drain, and a destination a request already anchored
        is rebuilt on its next span, which would shed another one. While the shed ones
        are stuck closing against a collector that stopped answering, evicting would
        churn the cache at one more processor, and one more batch thread, per span.
        Holding above the cap instead keeps the total at one processor per destination
        in flight, since ``deliverable`` anchors no new destination while the drain is
        saturated. Once it has room again, every hit and build trims one entry.
        """
        if len(self._processors) <= _MAX_CACHED_DESTINATION_PROCESSORS or self._drain.saturated():
            return
        _, evicted = self._processors.popitem(last=False)
        self._retired[id(evicted)] = evicted

    def _drainable_locked(self) -> tuple[SpanProcessor, ...]:
        """Retired processors no thread is exporting through, removed from the list.

        ``on_end`` holds a processor across an export, so closing an evicted one there
        drops the span it is holding. A retiree is out of the cache and can never be
        handed out again, so once its export count reaches zero it stays there.
        """
        idle: Final = tuple(key for key in self._retired if self._exporting.get(key, 0) == 0)
        return tuple(self._retired.pop(key) for key in idle)


def _destination_processor(destination: "OtelDestination") -> SpanProcessor | None:
    """A batching OTLP processor aimed at ``destination``, or ``None`` if unbuildable.

    A protocol that resolves to a headerless exporter is unbuildable too: the
    console fallback would swallow the tenant's credentials and print its spans to
    the proxy's stdout while the operator's exporter stands down for them.
    """
    kind: Final = destination.protocol or "otlp_http"
    if exporter_transport(kind) == "headerless":
        verbose_logger.debug("OTel V2 fan-out: no OTLP transport for protocol %r at %s", kind, destination.endpoint)
        return None
    try:
        spec: Final = ExporterSpec(
            kind=kind,
            endpoint=destination.endpoint,
            headers=destination.header_string(),
            owner=None,
        )
        return _processor_for(_exporter_from_spec(spec), use_simple=False)
    except Exception as exc:  # noqa: BLE001  # a malformed destination must not break the request or the other destinations
        verbose_logger.debug("OTel V2 fan-out: no processor for %s: %s", destination.endpoint, exc)
        return None


def _shutdown_quietly(processor: SpanProcessor) -> None:
    try:
        processor.shutdown()
    except Exception as exc:  # noqa: BLE001  # defensive: shedding a spare processor must not raise
        verbose_logger.debug("OTel V2 fan-out: discarding processor failed: %s", exc)


class _OverriddenBackendFilter(SpanProcessor):
    """Hold a span back from ``owner``'s operator-level exporter when the request
    pointed ``owner`` at a tenant's own account.

    Wrapping is the only place this works: ``SynchronousMultiSpanProcessor.on_end``
    ignores return values, so a sibling processor can never veto the export.

    Under ``additive`` mode spans are not suppressed, though global content policy
    still strips message content when disabled.

    ``scope`` narrows what the exporter receives independently of that: under
    ``llm_only`` the model-call spans go through as trace roots and the rest of the
    tree is held back, unless a destination of the request names ``sink``, the account
    this exporter writes to, with a wider scope: the fan-out then delivers the rest of
    the tree there and the model call keeps its place in it. A destination naming
    ``sink`` sets this exporter's content policy; otherwise it follows global capture.
    """

    def __init__(
        self,
        inner: SpanProcessor,
        owner: str | None,
        scope: "OtelSpanScope" = "full",
        sink: _SinkKey | None = None,
        global_captures: bool = True,
        filter_content: bool = True,
    ) -> None:
        self._inner: Final = inner
        self._owner: Final = owner
        self._scope: Final = scope
        self._sink: Final = sink
        self._global_captures: Final = global_captures
        self._filter_content: Final = filter_content

    def on_start(self, span: SDKSpan, parent_context: Context | None = None) -> None:
        self._inner.on_start(span, parent_context)

    def on_end(self, span: ReadableSpan) -> None:
        if self._owner in suppressed_backends() or not _in_scope(span, self._scope):
            return
        scoped: Final = _scoped(span, self._account_scope())
        self._inner.on_end(
            without_message_content(scoped) if self._filter_content and not self._account_captures_content() else scoped
        )

    def _account_captures_content(self) -> bool:
        """Whether a destination of this request that names ``sink`` captures content.

        The fan-out skips a destination this exporter already writes to, so this copy is
        the one that account gets and has to honor the destination's content mode.
        """
        explicit: Final = next(
            (
                destination.capture_message_content
                for destination in request_destinations()
                if self._sink is not None
                and destination.capture_message_content is not None
                and _sink_key(destination.endpoint, destination.headers) == self._sink
            ),
            None,
        )
        return captures_span_content(explicit) if explicit is not None else self._global_captures

    def _account_scope(self) -> "OtelSpanScope":
        if self._scope == "full" or self._sink is None:
            return self._scope
        shared: Final = tuple(
            destination.span_scope
            for destination in request_destinations()
            if _sink_key(destination.endpoint, destination.headers) == self._sink
        )
        return _widest((self._scope, *shared))

    def shutdown(self) -> None:
        self._inner.shutdown()

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        return self._inner.force_flush(timeout_millis)


class _DestinationLangfuseAttributeFilter(SpanProcessor):
    """Strip the Langfuse attributes only a Langfuse destination asked for from LiteLLM's own spans before ``inner``
    exports them."""

    def __init__(self, inner: SpanProcessor, langfuse_mapped: bool) -> None:
        self._inner: Final = inner
        self._langfuse_mapped: Final = langfuse_mapped

    def on_start(self, span: SDKSpan, parent_context: Context | None = None) -> None:
        self._inner.on_start(span, parent_context)

    def on_end(self, span: ReadableSpan) -> None:
        self._inner.on_end(without_destination_langfuse_attributes(span, self._langfuse_mapped))

    def shutdown(self) -> None:
        self._inner.shutdown()

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        return self._inner.force_flush(timeout_millis)


class _MessageContentFilter(SpanProcessor):
    """Strip prompt and response content from every span before ``inner`` exports it."""

    def __init__(self, inner: SpanProcessor) -> None:
        self._inner: Final = inner

    def on_start(self, span: SDKSpan, parent_context: Context | None = None) -> None:
        self._inner.on_start(span, parent_context)

    def on_end(self, span: ReadableSpan) -> None:
        self._inner.on_end(without_message_content(span))

    def shutdown(self) -> None:
        self._inner.shutdown()

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        return self._inner.force_flush(timeout_millis)


def build_span_exporter(config: OpenTelemetryV2Config) -> SpanExporter:
    """Build a single exporter from the top-level config fields.

    Convenience for the common single-exporter case (and for tests): reads the
    ``exporter`` / ``endpoint`` / ``headers`` fields. To configure multiple
    exporters, populate ``config.exporters`` directly.
    """
    return _exporter_from_spec(
        ExporterSpec(
            kind=config.exporter,
            endpoint=config.endpoint,
            traces_endpoint=config.traces_endpoint,
            headers=config.headers,
        )
    )


def _otlp_metrics_endpoint(endpoint: str | None) -> str | None:
    """Point an OTLP/HTTP base endpoint at the ``/v1/metrics`` signal path.

    The OTLP/HTTP exporter only appends ``/v1/metrics`` when it reads
    ``OTEL_EXPORTER_OTLP_ENDPOINT`` itself; an explicitly passed endpoint is used
    verbatim, so a base URL would POST to the root. Mirror ``_otlp_traces_endpoint``
    for the metrics signal (rewriting a sibling signal path when present).
    """
    if not endpoint:
        return endpoint
    endpoint = endpoint.rstrip("/")
    if endpoint.endswith("/v1/metrics"):
        return endpoint
    for other_signal in ("/v1/traces", "/v1/logs"):
        if endpoint.endswith(other_signal):
            return endpoint[: -len(other_signal)] + "/v1/metrics"
    return endpoint + "/v1/metrics"


def build_metric_reader(config: OpenTelemetryV2Config) -> "MetricReader":
    """Build a metric reader mirroring v1's exporter selection.

    ``console`` (and any unrecognized kind) exports to the console; ``otlp_http``
    and ``otlp_grpc`` export over OTLP with the configured endpoint/headers. The
    reader exports on a 5s period, matching v1.

    Histograms keep the SDK's default cumulative temporality. Prometheus-backed
    OTLP receivers (Grafana Cloud / Mimir, and the Prometheus OTLP endpoint)
    reject delta histograms outright with ``invalid temporality and type
    combination``, which drops the whole metric batch, while backends that
    prefer delta still accept cumulative. The enterprise billing exporter
    already relies on the same default.
    """
    from opentelemetry.sdk.metrics.export import (
        ConsoleMetricExporter,
        PeriodicExportingMetricReader,
    )

    kind: Final = (config.exporter or "console").lower()
    if kind in ("otlp_http", "http", "http/protobuf", "http/json"):
        from opentelemetry.exporter.otlp.proto.http.metric_exporter import (
            OTLPMetricExporter as HTTPMetricExporter,
        )

        tls: Final = resolve_otlp_http_tls("METRICS")
        exporter: object = HTTPMetricExporter(
            endpoint=_otlp_metrics_endpoint(config.endpoint),
            headers=parse_headers(config.headers),
            certificate_file=tls.certificate_file,
            session=tls.session,
        )
    elif kind in ("otlp_grpc", "grpc"):
        try:
            from opentelemetry.exporter.otlp.proto.grpc.metric_exporter import (
                OTLPMetricExporter as GRPCMetricExporter,
            )
        except ImportError as exc:
            raise ImportError(
                "OpenTelemetry OTLP gRPC metric exporter is not available. Install "
                "`opentelemetry-exporter-otlp` and `grpcio` (or `litellm[grpc]`)."
            ) from exc

        exporter = GRPCMetricExporter(
            endpoint=config.endpoint,
            headers=parse_headers(config.headers),
        )
    else:
        exporter = ConsoleMetricExporter()

    return PeriodicExportingMetricReader(exporter, export_interval_millis=5000)


def _otlp_logs_endpoint(endpoint: str | None) -> str | None:
    """Point an OTLP/HTTP base endpoint at the ``/v1/logs`` signal path.

    The OTLP/HTTP exporter only appends ``/v1/logs`` when it reads
    ``OTEL_EXPORTER_OTLP_ENDPOINT`` itself; an explicitly passed endpoint is used
    verbatim, so a base URL would POST to the root. Mirror ``_otlp_traces_endpoint``
    for the logs signal (rewriting a sibling signal path when present).
    """
    if not endpoint:
        return endpoint
    endpoint = endpoint.rstrip("/")
    if endpoint.endswith("/v1/logs"):
        return endpoint
    for other_signal in ("/v1/traces", "/v1/metrics"):
        if endpoint.endswith(other_signal):
            return endpoint[: -len(other_signal)] + "/v1/logs"
    return endpoint + "/v1/logs"


def build_log_exporter(config: OpenTelemetryV2Config) -> LogExporter:
    """Build a log exporter mirroring the exporter selection of the other signals.

    ``console`` (and any unrecognized kind) exports to the console; ``otlp_http``
    and ``otlp_grpc`` export over OTLP with the configured endpoint/headers;
    ``in_memory`` buffers for tests. Like GenAI metrics, events ride the
    single-destination shorthand fields, not the multi-exporter ``exporters`` list.
    """
    kind: Final = (config.exporter or "console").lower()
    if kind in ("in_memory", "inmemory", "memory"):
        return InMemoryLogExporter()
    if kind in ("otlp_http", "http", "http/protobuf", "http/json"):
        from opentelemetry.exporter.otlp.proto.http._log_exporter import (
            OTLPLogExporter as HTTPLogExporter,
        )

        tls: Final = resolve_otlp_http_tls("LOGS")
        return HTTPLogExporter(
            endpoint=_otlp_logs_endpoint(config.endpoint),
            headers=parse_headers(config.headers),
            certificate_file=tls.certificate_file,
            session=tls.session,
        )
    if kind in ("otlp_grpc", "grpc"):
        try:
            from opentelemetry.exporter.otlp.proto.grpc._log_exporter import (
                OTLPLogExporter as GRPCLogExporter,
            )
        except ImportError as exc:
            raise ImportError(
                "OpenTelemetry OTLP gRPC log exporter is not available. Install "
                "`opentelemetry-exporter-otlp` and `grpcio` (or `litellm[grpc]`)."
            ) from exc

        return GRPCLogExporter(endpoint=config.endpoint, headers=parse_headers(config.headers))
    return ConsoleLogExporter()


def build_logger_provider(
    config: OpenTelemetryV2Config,
    log_exporter: LogExporter | None = None,
) -> SDKLoggerProvider:
    """Build the :class:`LoggerProvider` GenAI events export through.

    ``log_exporter`` is an explicit override (tests inject an
    ``InMemoryLogExporter``); otherwise the exporter is selected from the config's
    exporter kind via :func:`build_log_exporter`. Console and in-memory exporters
    get a Simple processor (synchronous export, which tests rely on), everything
    else a Batch processor — the same split as span processing.
    """
    exporter: Final = log_exporter if log_exporter is not None else build_log_exporter(config)
    provider: Final = SDKLoggerProvider(resource=build_resource(config))
    use_simple: Final = isinstance(exporter, (ConsoleLogExporter, InMemoryLogExporter))
    provider.add_log_record_processor(
        SimpleLogRecordProcessor(exporter) if use_simple else BatchLogRecordProcessor(exporter)
    )
    return provider


def resolve_logger_provider(
    config: OpenTelemetryV2Config,
    logger_provider: SDKLoggerProvider | None = None,
) -> SDKLoggerProvider | None:
    """Resolve the :class:`LoggerProvider` GenAI events record through, or ``None``
    when the operator has opted out of the logs signal.

    Same resolution order as :func:`resolve_meter_provider`: an injected provider
    wins (DI/tests); an operator-configured SDK global is reused so events ride
    their pipeline; an explicit ``NoOpLoggerProvider`` global is an opt-out and
    yields ``None``, so no event is ever built. Only the default placeholder
    global makes V2 build a provider from the config and publish it as the global.
    """
    if logger_provider is not None:
        return logger_provider

    existing: Final[LoggerProvider] = _logs.get_logger_provider()
    if isinstance(existing, SDKLoggerProvider):
        return existing
    if isinstance(existing, NoOpLoggerProvider):
        return None

    provider: Final = build_logger_provider(config)
    _logs.set_logger_provider(provider)
    return provider


def get_event_logger(provider: SDKLoggerProvider, name: str = "litellm") -> Logger:
    return provider.get_logger(name, litellm_version)


def build_meter_provider(
    config: OpenTelemetryV2Config,
    metric_reader: "MetricReader | None" = None,
) -> SDKMeterProvider:
    """Build the :class:`MeterProvider` for GenAI metrics.

    ``metric_reader`` is an explicit override (tests inject an
    ``InMemoryMetricReader``); otherwise the reader is selected from the config's
    exporter kind via :func:`build_metric_reader`.
    """
    reader: Final = metric_reader if metric_reader is not None else build_metric_reader(config)
    return SDKMeterProvider(metric_readers=[reader], resource=build_resource(config))


def resolve_meter_provider(
    config: OpenTelemetryV2Config,
    meter_provider: MeterProvider | None = None,
) -> MeterProvider:
    """Resolve the :class:`MeterProvider` GenAI metrics record through.

    An injected provider wins (DI/tests). Otherwise reuse whatever the operator has
    configured as the global, whether a real SDK provider or an explicit
    ``NoOpMeterProvider``, so the GenAI histograms ride the operator's
    readers/exporters and an explicit opt-out is honored. Only when the global is
    still the default proxy placeholder does V2 build one from the config and
    publish it as the global, mirroring how V2 owns trace export. The built
    provider is the one returned, so its reader thread is always live, never
    orphaned.
    """
    if meter_provider is not None:
        return meter_provider

    existing: Final = metrics.get_meter_provider()
    if isinstance(existing, (SDKMeterProvider, NoOpMeterProvider)):
        return existing

    provider: Final = build_meter_provider(config)
    metrics.set_meter_provider(provider)
    return provider


def get_meter(provider: MeterProvider, name: str = "litellm") -> "Meter":
    return provider.get_meter(name, litellm_version)


def build_resource(config: OpenTelemetryV2Config) -> Resource:
    attributes: Final[dict[str, str]] = {"service.name": config.service_name}
    if config.deployment_environment:
        attributes["deployment.environment"] = config.deployment_environment
    attributes.update(config.resource_attributes)
    return Resource.create(attributes)


def _spec_processor(
    spec: ExporterSpec,
    use_simple_processor: bool | None,
    strip_message_content: bool,
    strip_destination_langfuse_attributes: bool,
    langfuse_mapped: bool,
) -> SpanProcessor:
    exporting: Final = _processor_for(
        _exporter_from_spec(spec),
        (spec.use_simple_processor if spec.use_simple_processor is not None else use_simple_processor),
    )
    scoped: Final = (
        _DestinationLangfuseAttributeFilter(exporting, langfuse_mapped)
        if strip_destination_langfuse_attributes
        else exporting
    )
    return _MessageContentFilter(scoped) if strip_message_content else scoped


class _RequestExclusionSampler(Sampler):
    def __init__(self, delegate: Sampler) -> None:
        self.delegate = delegate

    def should_sample(
        self,
        parent_context: Context | None,
        trace_id: int,
        name: str,
        kind: SpanKind | None = None,
        attributes: Attributes = None,
        links: Sequence[Link] | None = None,
        trace_state: TraceState | None = None,
    ) -> SamplingResult:
        if request_traces_excluded():
            return SamplingResult(Decision.DROP)
        return self.delegate.should_sample(parent_context, trace_id, name, kind, attributes, links, trace_state)

    def get_description(self) -> str:
        return f"RequestExclusion({self.delegate.get_description()})"


def build_tracer_provider(
    config: OpenTelemetryV2Config,
    exporter: SpanExporter | None = None,
    baggage_processor: SpanProcessor | None = None,
    use_simple_processor: bool | None = None,
    tenant_overrides: bool = False,
    strip_message_content: bool = False,
    console_default: bool = False,
) -> TracerProvider:
    """Build the shared :class:`TracerProvider`.

    Attach the Baggage processor first (so identity attributes land on each
    span before any export decision), then add one ``SpanProcessor`` per
    ``config.exporters`` entry — this is what fans spans out to multiple
    backends. ``exporter`` and ``use_simple_processor`` are explicit overrides:
    pass a single exporter to attach exactly that one (used by tests).

    ``tenant_overrides`` wraps each owned exporter so a request that pointed that
    backend at a key's or team's own account skips it. Every v2 logger's provider
    wants it, since any of them may own the overridden backend; delivering to the
    tenant is a separate job, done once by :func:`attach_tenant_fan_out`. The
    per-tenant providers this same function builds must leave it off, or they would
    filter out the very spans they exist to carry.

    ``config.langfuse_span_scope`` narrows the exporter owned by ``langfuse_otel``
    alone; a collector or any other backend in the same config keeps the full tree.
    Every exporter but ``langfuse_otel``'s goes without the Langfuse attributes only a
    Langfuse destination asked for (see :func:`without_destination_langfuse_attributes`),
    which any logger writes for a request with a Langfuse destination.
    ``strip_message_content`` removes prompt and response content before every
    exporter, for a routed provider whose spans can carry content another
    destination asked for.

    The console spec ``config._normalize`` folds in when nothing was configured
    prints only under ``console_default``, which the ``otel`` callback passes: a
    vendor preset or the proxy's background global logger was never asked to print.
    """
    provider: Final = TracerProvider(resource=build_resource(config))
    provider.sampler = _RequestExclusionSampler(provider.sampler)
    if baggage_processor is None:
        baggage_processor = LiteLLMBaggageSpanProcessor(allowed_keys=config.baggage_promoted_keys)
    provider.add_span_processor(baggage_processor)

    if exporter is not None:
        provider.add_span_processor(_processor_for(exporter, use_simple_processor))
        return provider

    langfuse_mapped: Final = _maps_langfuse(config)
    # ``config._normalize`` guarantees at least one spec (it folds the top-level
    # ``exporter``/``endpoint``/``headers`` fields in when ``exporters`` is empty).
    for spec in config.exporters:
        if spec.requires_headers and not spec.headers:
            continue
        if is_unconfigured_placeholder(spec) and not console_default:
            continue
        processor = _spec_processor(
            spec,
            use_simple_processor,
            strip_message_content,
            strip_destination_langfuse_attributes=spec.owner is not ExporterOwner.LANGFUSE_OTEL,
            langfuse_mapped=langfuse_mapped,
        )
        owner = spec.owner.value if tenant_overrides and spec.owner is not None else None
        scope = _operator_scope(config, spec)
        sink = _sink_key(spec.endpoint, parse_headers(spec.headers)) if _exports_to_the_wire(spec) else None
        provider.add_span_processor(
            _OverriddenBackendFilter(
                processor,
                owner,
                scope,
                sink,
                config.capture_span_content,
                tenant_overrides,
            )
            if owner is not None
            or scope != "full"
            or sink is not None
            or (tenant_overrides and not config.capture_span_content)
            else processor
        )
    return provider


_FAN_OUT_ATTACH_LOCK: Final = threading.Lock()


def attach_tenant_fan_out(
    provider: TracerProvider, *configs: OpenTelemetryV2Config, excluded_db_systems: frozenset[str] = frozenset()
) -> None:
    """Give ``provider`` the fan-out that delivers spans to key/team destinations.

    Called on the one provider published as the OTel global, and idempotent so a
    second publish (a test, a re-initialized proxy) cannot double-export. Concurrent
    first calls (requests racing to anchor before any publish) serialize on one lock
    so exactly one fan-out lands. ``configs`` name the operator's own exporters, one
    config per v2 logger since each keeps its own provider and still writes its
    account, so an additive destination pointing at any of them is delivered once
    rather than twice. The first is the config of the logger that owns ``provider``,
    whose model calls the fan-out carries. ``excluded_db_systems`` only filters what
    the fan-out delivers, never the operator's own exporters.
    """
    with _FAN_OUT_ATTACH_LOCK:
        if any(isinstance(processor, TenantFanOutSpanProcessor) for processor in _attached_processors(provider)):
            return
        provider.add_span_processor(
            TenantFanOutSpanProcessor(
                operator_sinks=operator_sink_scopes(*configs),
                excluded_db_systems=excluded_db_systems,
                default_capture=_operator_capture_mode(configs),
                default_capture_by_backend=MappingProxyType(dict(_owned_capture_modes(configs))),
                langfuse_mapped=any(_maps_langfuse(config) for config in configs[:1]),
            )
        )


def _maps_langfuse(config: OpenTelemetryV2Config) -> bool:
    """Whether a logger built from ``config`` writes the Langfuse vocabulary on every model call."""
    return "langfuse" in config.mapper_names


def _operator_capture_mode(configs: Sequence[OpenTelemetryV2Config]) -> str:
    """The mode of the operator's generic ``otel`` callback, so ``callback_settings.otel`` counts as the global default"""
    return next(
        (config.capture_message_content for config in configs if any(spec.owner is None for spec in config.exporters)),
        capture_message_content_from_env(),
    )


def _owned_capture_modes(
    configs: Sequence[OpenTelemetryV2Config],
) -> Iterator[tuple[str, str]]:
    for config in configs:
        for spec in config.exporters:
            if spec.owner is not None:
                yield spec.owner.value, config.capture_message_content


def deliverable_destinations(
    destinations: Iterable["OtelDestination"],
    provider: trace.TracerProvider | None = None,
) -> tuple["OtelDestination", ...]:
    """The destinations a request can anchor, given what is published to carry them.

    Anchoring a destination is what tells the operator's own exporter to stand down
    for that backend, so one nothing can deliver has to be dropped here: with no
    fan-out attached, or with an exporter that will not build, the request keeps
    exactly the routing it would have had without any override.
    """
    fan_out: Final = next(
        (
            processor
            for processor in _attached_processors(provider if provider is not None else trace.get_tracer_provider())
            if isinstance(processor, TenantFanOutSpanProcessor)
        ),
        None,
    )
    return fan_out.deliverable(destinations) if fan_out is not None else ()


def operator_sink_scopes(*configs: OpenTelemetryV2Config) -> 'Mapping[_SinkKey, "OtelSpanScope"]':
    """The accounts the operator's own exporters write to, in destination terms.

    Every v2 logger's config counts, since each logger exports through its own
    provider. An exporter with no endpoint of its own resolves one from the
    environment at export time, so it has no comparable identity and is left out,
    and so is one that never reaches the wire: a console kind ignores the endpoint,
    and a header-gated spec with no credentials is skipped when the provider is built.
    """
    scoped: Final[tuple[tuple[_SinkKey, OtelSpanScope], ...]] = tuple(
        (key, _operator_scope(config, spec))
        for config in configs
        for spec in config.exporters
        if _exports_to_the_wire(spec) and (key := _sink_key(spec.endpoint, parse_headers(spec.headers))) is not None
    )
    return MappingProxyType({key: _widest(scope for other, scope in scoped if other == key) for key, _ in scoped})


def _operator_scope(config: OpenTelemetryV2Config, spec: ExporterSpec) -> "OtelSpanScope":
    return config.langfuse_span_scope if spec.owner is ExporterOwner.LANGFUSE_OTEL else "full"


def _widest(scopes: "Iterable[OtelSpanScope]") -> "OtelSpanScope":
    return "full" if any(scope == "full" for scope in scopes) else "llm_only"


def _exports_to_the_wire(spec: ExporterSpec) -> bool:
    """Whether ``build_tracer_provider`` gives ``spec`` an exporter that sends OTLP."""
    return exporter_transport(spec.kind) != "headerless" and not (spec.requires_headers and not spec.headers)


def _sink_key(endpoint: str | None, headers: Mapping[str, str]) -> "_SinkKey | None":
    """The account an exporter writes to, or ``None`` when it has no fixed one.

    Normalized on the three counts that make one account look like two: the operator's
    spec carries the signal path a tenant destination leaves for the exporter to
    append, header names survive one round trip lowercased and the other not, and one
    credential answers to more than one name (see :data:`_CREDENTIAL_ALIASES`).
    """
    normalized: Final = _otlp_traces_endpoint(endpoint)
    if normalized is None:
        return None
    return (normalized, tuple(sorted((_credential_name(name), value) for name, value in headers.items())))


def _credential_name(header: str) -> str:
    """The credential a header carries, under whichever name the backend spells it."""
    normalized: Final = header.strip().lower().replace("-", "_")
    return _CREDENTIAL_ALIASES.get(normalized, normalized)


def _attached_processors(provider: trace.TracerProvider) -> "tuple[SpanProcessor, ...]":
    """The processors already on ``provider``, or empty when the SDK hides them."""
    multi: Final = getattr(provider, "_active_span_processor", None)
    return tuple(getattr(multi, "_span_processors", ()))


def get_tracer(provider: TracerProvider, name: str = LITELLM_TRACER_NAME) -> Tracer:
    # Stamp the instrumentation scope with the LiteLLM package version so every
    # emitted span carries a deterministic ``scope.version`` (the standard OTel
    # location for the emitting library's version) for downstream consumers.
    return provider.get_tracer(name, litellm_version)


def in_memory_provider(
    config: OpenTelemetryV2Config | None = None,
) -> tuple[TracerProvider, InMemorySpanExporter]:
    """Convenience for tests: a provider exporting to an in-memory buffer."""
    cfg: Final = config or OpenTelemetryV2Config(exporter="in_memory")
    exporter: Final = InMemorySpanExporter()
    provider: Final = build_tracer_provider(cfg, exporter=exporter)
    return provider, exporter
