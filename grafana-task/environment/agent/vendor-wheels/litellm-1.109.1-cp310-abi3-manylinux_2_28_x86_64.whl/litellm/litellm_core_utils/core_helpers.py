# What is this?
## Helper utilities
import copy
import logging
import math
import re
from collections.abc import Collection, Iterable, Iterator, Mapping
from types import MappingProxyType
from typing import TYPE_CHECKING, Any, Final, Literal, Protocol, TypeVar, cast, runtime_checkable

import httpx
from pydantic import BaseModel, TypeAdapter, ValidationError
from typing_extensions import TypeIs  # noqa: TID251  # narrows a duck-typed value to the Protocol its caller reads

import litellm
from litellm._logging import verbose_logger
from litellm.constants import KUBERNETES_POD_ROUTING_KEY
from litellm.litellm_core_utils.hidden_params import set_extra_attribute
from litellm.litellm_core_utils.llm_response_utils.get_headers import get_provider_request_id
from litellm.types.llms.openai import AllMessageValues, OpenAIChatCompletionFinishReason

if TYPE_CHECKING:
    from opentelemetry.trace import Span as _Span

    from litellm.types.utils import ModelResponseStream, StandardLoggingKubernetesPodRouting

    Span = _Span | Any
else:
    Span = Any


_CODEX_CLIENT_PREFIX_RE: Final = re.compile(r"^codex[-_ /]", re.IGNORECASE)


def is_codex_user_agent(user_agent: str) -> bool:
    return bool(_CODEX_CLIENT_PREFIX_RE.match(user_agent))


def qualify_provider_stripped_model(model: str, custom_llm_provider: str) -> str:
    """Put the provider prefix back on a provider-stripped model."""
    if not custom_llm_provider or model.startswith(f"{custom_llm_provider}/"):
        return model
    if _already_routes_to(model, custom_llm_provider):
        return model
    return f"{custom_llm_provider}/{model}"


def _already_routes_to(model: str, custom_llm_provider: str) -> bool:
    from litellm.litellm_core_utils.get_llm_provider_logic import inferred_provider

    return _leads_with_provider(model) and inferred_provider(model) == custom_llm_provider


def _leads_with_provider(model: str) -> bool:
    leading_segment, separator, _ = model.partition("/")
    return bool(separator) and names_a_provider(leading_segment)


def names_a_provider(candidate: str) -> bool:
    """Whether a model name's leading segment is a provider rather than part of the model."""
    import litellm
    from litellm.litellm_core_utils.get_llm_provider_logic import is_registered_custom_provider
    from litellm.llms.openai_like.json_loader import JSONProviderRegistry

    provider_names: Final = {getattr(provider, "value", provider) for provider in litellm.provider_list}
    return (
        candidate in provider_names
        or JSONProviderRegistry.exists(candidate)
        or is_registered_custom_provider(candidate)
    )


def qualify_agentic_followup_model(patch_model: str | None, model: str, custom_llm_provider: str) -> str:
    """Resolve the model an agentic follow-up re-dispatches, keeping a hook's own provider."""
    if not patch_model or patch_model == model:
        return qualify_provider_stripped_model(model, custom_llm_provider)
    if _leads_with_provider(patch_model):
        return patch_model
    return qualify_provider_stripped_model(patch_model, custom_llm_provider)


def safe_divide_seconds(seconds: float, denominator: float, default: float | None = None) -> float | None:
    """
    Safely divide seconds by denominator, handling zero division.

    Args:
        seconds: Time duration in seconds
        denominator: The divisor (e.g., number of tokens)
        default: Value to return if division by zero (defaults to None)

    Returns:
        The result of the division as a float (seconds per unit), or default if denominator is zero
    """
    if denominator <= 0:
        return default

    return float(seconds / denominator)


_DROP_PARAMS_BOOL: Final = TypeAdapter(bool)


def as_str_mapping(value: object) -> Mapping[str, object] | None:
    return value if isinstance(value, Mapping) else None


def decoded_json_object(value: object) -> Mapping[str, object]:
    mapping: Final = as_str_mapping(value)
    if mapping is not None:
        return mapping
    raise AttributeError(f"{type(value).__name__!r} object has no attribute 'get'", name="get", obj=value)


@runtime_checkable
class _SupportsIter(Protocol):
    def __iter__(self) -> Iterator[object]: ...


@runtime_checkable
class _SupportsGetItem(Protocol):
    def __getitem__(self, index: int, /) -> object: ...


def attribute_or_none(source: object, name: str) -> object:
    return getattr(source, name, None)


_Shape: Final = TypeVar("_Shape")


def has_attributes(
    value: object,
    shape: type[_Shape],
    *names: str,
) -> TypeIs[_Shape]:  # guard-ok: hasattr sees what __getattr__ serves, which Protocol isinstance skips on 3.12+
    return all(hasattr(value, name) for name in names)


def require_attributes(value: object, shape: type[_Shape], *names: str) -> _Shape:
    if has_attributes(value, shape, *names):
        return value
    missing: Final = next(name for name in names if not hasattr(value, name))
    raise AttributeError(f"'{type(value).__name__}' object has no attribute '{missing}'", name=missing, obj=value)


def iter_items(value: object) -> Iterable[object]:
    if isinstance(value, _SupportsIter):
        return value
    if isinstance(value, _SupportsGetItem):
        return iter(value)
    raise TypeError(f"'{type(value).__name__}' object is not iterable")


def attribute_items(source: object, name: str) -> Iterable[object]:
    value: Final = attribute_or_none(source, name)
    return iter_items(value) if value else ()


def normalize_drop_params(value: object) -> bool | None:
    if value is None or isinstance(value, bool):
        return value
    try:
        return _DROP_PARAMS_BOOL.validate_python(value.strip() if isinstance(value, str) else value)
    except ValidationError:
        return None


def drops_unsupported_params(drop_params: object) -> bool:
    return litellm.drop_params is True or normalize_drop_params(drop_params) is True


def drop_params_flag(value: object, source: str, logger: logging.Logger) -> bool:
    normalized: Final = normalize_drop_params(value)
    if normalized is None and value is not None:
        logger.warning("%s=%r is not a flag value, treating it as off", source, value)
    return bool(normalized)


DROP_PARAMS_ENV_VAR: Final = "LITELLM_DROP_PARAMS"


def drop_params_env_flag(environ: Mapping[str, str], logger: logging.Logger) -> bool:
    configured: Final = environ.get(DROP_PARAMS_ENV_VAR, "").strip()
    if configured == "":
        return False
    normalized: Final = normalize_drop_params(configured)
    if normalized is None:
        logger.warning(
            "%s=%r is not a flag value, treating it as on. Set it to true or false", DROP_PARAMS_ENV_VAR, configured
        )
        return True
    return normalized


def safe_divide(
    numerator: float,
    denominator: float,
    default: float = 0,
) -> int | float:
    """
    Safely divide two numbers, returning a default value if denominator is zero.

    Args:
        numerator: The number to divide
        denominator: The number to divide by
        default: Value to return if denominator is zero (defaults to 0)

    Returns:
        The result of numerator/denominator, or default if denominator is zero
    """
    if denominator == 0:
        return default
    return numerator / denominator


def _is_litellm_limit_rejection(exception: BaseException) -> bool:
    from litellm.exceptions import RateLimitErrorCategory

    litellm_limit_categories: Final = frozenset(
        (RateLimitErrorCategory.LITELLM_RATE_LIMIT.value, RateLimitErrorCategory.LITELLM_BATCH_RATE_LIMIT.value)
    )
    return getattr(exception, "category", None) in litellm_limit_categories


def _is_proxy_rejection(exception: BaseException) -> bool:
    if _is_litellm_limit_rejection(exception):
        return True
    try:
        from starlette.exceptions import HTTPException
    except ImportError:
        return False
    return isinstance(exception, HTTPException)


def _is_provider_originated(exception: BaseException) -> bool:
    if _is_proxy_rejection(exception):
        return False
    if getattr(exception, "llm_provider", None):
        return True
    from litellm.llms.base_llm.chat.transformation import BaseLLMException

    return isinstance(exception, BaseLLMException)


def is_expected_client_error(exception: BaseException | None) -> bool:
    """
    True when the proxy itself rejected the request with an HTTP 4xx before any
    provider call (bad key, budget, unknown model, guardrail). A 4xx returned by
    a provider is an upstream or deployment problem, so it is never an expected
    client error and keeps its traceback: a mapped litellm exception carries
    ``llm_provider``, and the raw ``BaseLLMException`` that provider handlers
    raise before mapping (the /v1/messages route surfaces it as-is) is one too.
    The proxy's own limiters raise ``HTTPException`` subclasses that also carry
    an ``llm_provider``, so any ``HTTPException`` stays a proxy rejection, and
    so does any exception whose unified rate-limit ``category`` names litellm's
    own limiter (``BudgetExceededError`` is a plain ``Exception`` that the auth
    handler decorates with the requested model's provider).

    ProxyException stores the status on .code (as a str), HTTPException and
    litellm exceptions on .status_code.
    """
    if exception is None:
        return False
    if _is_provider_originated(exception):
        return False
    code: Final[object] = getattr(exception, "code", None)
    status_code: Final[object] = code if code is not None else getattr(exception, "status_code", None)
    if status_code is None or isinstance(status_code, bool):
        return False
    try:
        status: Final = int(str(status_code))
    except ValueError:
        return False
    return 400 <= status < 500


def coerce_token_limit(value: object) -> int | None:
    """
    Coerce a max_input_tokens / max_output_tokens value to an int, treating a
    malformed value as absent.

    A deployment's model_info is registered into litellm.model_cost verbatim, so a
    config value like "128,000" or "" reaches the /v1/models listing uncoerced from
    both the router index and the cost map. Returning None omits that one limit
    instead of failing the whole listing.

    Args:
        value: The raw configured or cost-map value

    Returns:
        The value as an int, or None if it is missing or not a usable number.
        Bools are rejected because True/False is never a meaningful token limit.
    """
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, (str, float)):
        try:
            return int(value)
        except (TypeError, ValueError, OverflowError):
            return None
    return None


_FINISH_REASON_MAP: Final[dict[str, OpenAIChatCompletionFinishReason]] = {
    # Anthropic
    "stop_sequence": "stop",
    "end_turn": "stop",
    "max_tokens": "length",
    "tool_use": "tool_calls",
    "refusal": "content_filter",
    "compaction": "length",
    "pause_turn": "length",
    "model_context_window_exceeded": "length",
    # Cohere
    "COMPLETE": "stop",
    "STOP_SEQUENCE": "stop",
    "TOOL_CALL": "tool_calls",
    "ERROR_TOXIC": "content_filter",
    "ERROR": "stop",
    # HuggingFace / Together AI
    "eos_token": "stop",
    "eos": "stop",
    # Gemini / Vertex AI
    "STOP": "stop",
    "MAX_TOKENS": "length",
    "CONTINUATION": "length",
    "SAFETY": "content_filter",
    "RECITATION": "content_filter",
    "FINISH_REASON_UNSPECIFIED": "stop",
    "MALFORMED_FUNCTION_CALL": "stop",
    "LANGUAGE": "content_filter",
    "OTHER": "content_filter",
    "BLOCKLIST": "content_filter",
    "PROHIBITED_CONTENT": "content_filter",
    "SPII": "content_filter",
    "IMAGE_SAFETY": "content_filter",
    "IMAGE_PROHIBITED_CONTENT": "content_filter",
    "TOO_MANY_TOOL_CALLS": "stop",
    "MALFORMED_RESPONSE": "stop",
    "NO_IMAGE": "content_filter",
    "IMAGE_RECITATION": "content_filter",
    "IMAGE_OTHER": "content_filter",
    "ESCALATION": "content_filter",
    "UNEXPECTED_TOOL_CALL": "stop",
    "MISSING_THOUGHT_SIGNATURE": "stop",
    # Zhipu GLM
    "network_error": "stop",
    "sensitive": "content_filter",
    # Bedrock
    "guardrail_intervened": "content_filter",
    # OpenAI passthrough
    "stop": "stop",
    "length": "length",
    "tool_calls": "tool_calls",
    "function_call": "function_call",
    "content_filter": "content_filter",
    # Anthropic Sonnet 4
    "content_filtered": "content_filter",
    # Generic error passthrough (OpenRouter and other OpenAI-compatible providers
    # emit lowercase "error" when a provider fails mid-stream)
    "error": "stop",
}


def map_finish_reason(finish_reason: str) -> OpenAIChatCompletionFinishReason:
    mapped: Final = _FINISH_REASON_MAP.get(finish_reason)
    if mapped is None:
        verbose_logger.warning("Unmapped finish_reason '%s', defaulting to 'stop'", finish_reason)
        return "stop"
    return mapped


def remove_index_from_tool_calls(
    messages: list[AllMessageValues] | None,
):
    if messages is not None:
        for message in messages:
            _tool_calls = message.get("tool_calls")
            if _tool_calls is not None and isinstance(_tool_calls, list):
                for tool_call in _tool_calls:
                    if isinstance(tool_call, dict) and "index" in tool_call:  # Type guard to ensure it's a dict
                        tool_call.pop("index", None)


class _PoppableByIndex(Protocol):
    def __len__(self) -> int: ...

    def pop(self, index: int, /) -> object: ...


def remove_items_at_indices(items: _PoppableByIndex | None, indices: Iterable[int]) -> None:
    """Remove items from a list in-place by index"""
    if items is None:
        return
    for index in sorted(set(indices), reverse=True):
        if 0 <= index < len(items):
            items.pop(index)


def add_missing_spend_metadata_to_litellm_metadata(litellm_metadata: dict, metadata: Mapping[str, object]) -> dict:
    """
    Helper to get litellm metadata for spend tracking

    PATCH for issue where both `litellm_metadata` and `metadata` are present in the kwargs
    and user_api_key values are in 'metadata'. The proxy receive stamp rides along for the same
    reason: a guardrail hook can plant `litellm_metadata` on a chat request after the proxy stamped
    `metadata`, and the response timing headers anchor on that stamp.
    """
    potential_spend_tracking_metadata_substring: Final = "user_api_key"
    for key, value in dict(metadata).items():
        carry_receive_stamp = key == "litellm_received_at" and key not in litellm_metadata
        if potential_spend_tracking_metadata_substring in key or carry_receive_stamp:
            litellm_metadata[key] = value
    return litellm_metadata


def get_metadata_variable_name_from_kwargs(
    kwargs: Mapping[str, object],
) -> Literal["metadata", "litellm_metadata"]:
    """
    Helper to return what the "metadata" field should be called in the request data

    - New endpoints return `litellm_metadata`
    - Old endpoints return `metadata`

    Context:
    - LiteLLM used `metadata` as an internal field for storing metadata
    - OpenAI then started using this field for their metadata
    - LiteLLM is now moving to using `litellm_metadata` for our metadata
    """
    return "litellm_metadata" if "litellm_metadata" in kwargs else "metadata"


def max_retries_per_request_hit(kwargs: Mapping[str, object], num_retries_per_request: int | None) -> bool:
    if num_retries_per_request is None:
        return False
    metadata: Final = kwargs.get(get_metadata_variable_name_from_kwargs(kwargs))
    if not isinstance(metadata, Mapping):
        return False
    retry_count: Final = metadata.get("request_retry_count")
    return type(retry_count) is int and 0 < retry_count and num_retries_per_request <= retry_count


def get_or_create_metadata_bucket(
    request_data: dict,
) -> tuple[Literal["metadata", "litellm_metadata"], dict]:
    """
    Return the proxy-internal metadata bucket for this request, creating it if absent.

    Batch/file routes store proxy state in ``litellm_metadata`` so the OpenAI
    ``metadata`` field can remain provider-safe (string values only). Every writer and
    reader of proxy-internal metadata resolves the bucket through here, so a caller that
    supplies its own ``metadata`` field cannot split them across two dicts.
    """
    metadata_key: Final = get_metadata_variable_name_from_kwargs(request_data)
    metadata_bucket = request_data.get(metadata_key)
    if not isinstance(metadata_bucket, dict):
        metadata_bucket = {}
        request_data[metadata_key] = metadata_bucket
    return metadata_key, metadata_bucket


def proxy_stamped_used_client_oauth_token(metadata: object, litellm_params: Mapping[str, object] | None) -> object:
    litellm_metadata: Final = litellm_params.get("litellm_metadata") if litellm_params is not None else None
    if isinstance(litellm_metadata, Mapping) and "used_client_oauth_token" in litellm_metadata:
        return litellm_metadata["used_client_oauth_token"]
    return metadata.get("used_client_oauth_token") if isinstance(metadata, Mapping) else None


def proxy_stamped_kubernetes_pod_routing(
    metadata: object,
    litellm_params: Mapping[str, object] | None,
) -> "StandardLoggingKubernetesPodRouting | None":
    litellm_metadata: Final = litellm_params.get("litellm_metadata") if litellm_params is not None else None
    litellm_routing: Final = _standard_logging_kubernetes_pod_routing(litellm_metadata)
    if litellm_routing is not None:
        return litellm_routing
    return _standard_logging_kubernetes_pod_routing(metadata)


def _standard_logging_kubernetes_pod_routing(
    metadata: object,
) -> "StandardLoggingKubernetesPodRouting | None":
    if not isinstance(metadata, Mapping):
        return None
    metadata_mapping: Final = cast(  # cast-ok: routing metadata is a string-keyed mapping
        Mapping[str, object], metadata
    )
    routing: Final = metadata_mapping.get(KUBERNETES_POD_ROUTING_KEY)
    if not isinstance(routing, Mapping):
        return None
    routing_mapping: Final = cast(  # cast-ok: pod routing records use string keys
        Mapping[str, object], routing
    )
    service_host: Final = routing_mapping.get("service_host")
    pod_ip: Final = routing_mapping.get("pod_ip")
    pod_count: Final = routing_mapping.get("pod_count")
    selection: Final = routing_mapping.get("selection")
    if (
        not isinstance(service_host, str)
        or not isinstance(pod_ip, str)
        or not isinstance(pod_count, int)
        or isinstance(pod_count, bool)
        or pod_count < 1
    ):
        return None
    if selection in ("round_robin", "session_affinity", "session_affinity_retry"):
        routing_record: Final[StandardLoggingKubernetesPodRouting] = {
            "service_host": service_host,
            "pod_ip": pod_ip,
            "pod_count": pod_count,
            "selection": selection,
        }
        return routing_record
    return None


def get_litellm_metadata_from_kwargs(kwargs: dict):
    """
    Helper to get litellm metadata from all litellm request kwargs

    Return `litellm_metadata` if it exists, otherwise return `metadata`
    """
    litellm_params: Final = kwargs.get("litellm_params", {})
    if litellm_params:
        metadata: Final = litellm_params.get("metadata", {})
        litellm_metadata = litellm_params.get("litellm_metadata", {})
        if litellm_metadata and metadata:
            litellm_metadata = add_missing_spend_metadata_to_litellm_metadata(litellm_metadata, metadata)
        if litellm_metadata:
            return litellm_metadata
        elif metadata:
            return metadata

    return {}


def _budget_reservation_on_auth_object(user_api_key_auth: object) -> object:
    if isinstance(user_api_key_auth, Mapping):
        return user_api_key_auth.get("budget_reservation")
    return getattr(user_api_key_auth, "budget_reservation", None)


def budget_reservation_from_metadata(metadata: Mapping[str, object]) -> dict[str, object] | None:
    stamped: Final = metadata.get("user_api_key_budget_reservation")
    if isinstance(stamped, dict):
        return stamped
    on_auth_object: Final = _budget_reservation_on_auth_object(metadata.get("user_api_key_auth"))
    return on_auth_object if isinstance(on_auth_object, dict) else None


def _stamp_budget_reservation_callback_bound(litellm_params: Mapping[str, object], callback_bound: bool) -> None:
    for metadata_variable_name in ("metadata", "litellm_metadata"):
        metadata = litellm_params.get(metadata_variable_name)
        if not isinstance(metadata, Mapping):
            continue
        budget_reservation = budget_reservation_from_metadata(metadata)
        if budget_reservation is not None:
            budget_reservation["callback_bound"] = callback_bound


def bind_budget_reservation_to_callbacks(litellm_params: Mapping[str, object]) -> None:
    """Mark the request's budget reservation as owned by the success callbacks of this call.

    The proxy releases any reservation still unbound when the request ends; one bound here
    is left for the cost callback, which may finish after the response has been sent. Bind
    only where a success handler is guaranteed to run: a logging object merely existing is
    not that, since the proxy builds one for every route before calling anything.
    """
    _stamp_budget_reservation_callback_bound(litellm_params, True)


def unbind_budget_reservation_from_callbacks(litellm_params: Mapping[str, object]) -> None:
    """Hand a failed call's reservation back to the request-end release: failure handlers never settle it."""
    _stamp_budget_reservation_callback_bound(litellm_params, False)


def reconstruct_model_name(
    model_name: str,
    custom_llm_provider: str | None,
    metadata: dict,
) -> str:
    """Reconstruct full model name with provider prefix for logging."""
    # Check if deployment model name from router metadata is available (has original prefix)
    deployment_model_name: Final = metadata.get("deployment")
    if deployment_model_name and "/" in deployment_model_name:
        # Use the deployment model name which preserves the original provider prefix
        return deployment_model_name
    elif custom_llm_provider and model_name and "/" not in model_name:
        # Only add prefix for Bedrock (not for direct Anthropic API)
        # This ensures Bedrock models get the prefix while direct Anthropic models don't
        if custom_llm_provider == "bedrock":
            return f"{custom_llm_provider}/{model_name}"
    return model_name


# Helper functions used for OTEL logging
def get_parent_otel_span_from_kwargs(
    kwargs: Mapping[str, object] | None = None,
) -> Span | None:
    try:
        if kwargs is None:
            return None
        litellm_params: Final = kwargs.get("litellm_params")
        metadata: Final = cast(  # cast-ok: metadata is caller-provided request data
            Mapping[str, object], kwargs.get("metadata") or {}
        )
        if "litellm_parent_otel_span" in metadata:
            return cast(  # cast-ok: tracing metadata crosses an external boundary
                Span | None, metadata["litellm_parent_otel_span"]
            )
        elif (
            litellm_params is not None
            and cast(Mapping[str, object], litellm_params).get("metadata") is not None
            and "litellm_parent_otel_span"
            in cast(
                Mapping[str, object],
                cast(Mapping[str, object], litellm_params).get("metadata", {}),
            )
        ):
            typed_litellm_params: Final = cast(Mapping[str, object], litellm_params)
            litellm_metadata: Final = cast(Mapping[str, object], typed_litellm_params["metadata"])
            return cast(Span | None, litellm_metadata["litellm_parent_otel_span"])
        elif "litellm_parent_otel_span" in kwargs:
            return cast(Span | None, kwargs["litellm_parent_otel_span"])
        return None
    except Exception as e:
        verbose_logger.exception("Error in _get_parent_otel_span_from_kwargs: " + str(e))
        return None


_get_parent_otel_span_from_kwargs = get_parent_otel_span_from_kwargs


def process_response_headers(
    response_headers: httpx.Headers | dict,
    preserve_litellm_internal_headers: bool = False,
) -> dict:
    """
    `preserve_litellm_internal_headers` must only be True when the input is a
    LiteLLM-owned dict (e.g. `_hidden_params["additional_headers"]` that has
    already been through one round of processing).  For raw upstream provider
    headers — whether passed as `httpx.Headers` or a plain dict — it must
    remain False, otherwise a malicious provider returning `x-litellm-*` could
    spoof LiteLLM-internal markers (e.g. `x-litellm-attempted-fallbacks`).

    When the input is an `httpx.Headers` object the flag is always treated as
    False regardless of what the caller requested, because `httpx.Headers` is
    always a raw provider response and can never be LiteLLM-owned.
    """
    from litellm.types.utils import OPENAI_RESPONSE_HEADERS

    # Raw httpx.Headers objects come directly from provider HTTP responses and
    # must never be treated as LiteLLM-owned, regardless of caller intent.
    _preserve: Final = preserve_litellm_internal_headers and isinstance(response_headers, dict)

    openai_headers: Final = {}
    processed_headers: Final = {}
    additional_headers = {}

    for k, v in response_headers.items():
        if k in OPENAI_RESPONSE_HEADERS:  # return openai-compatible headers
            openai_headers[k] = v
        if k.startswith("llm_provider-"):  # return raw provider headers (incl. openai-compatible ones)
            processed_headers[k] = v
        elif _preserve and k.startswith("x-litellm-"):
            # LiteLLM's own internal headers (e.g. x-litellm-attempted-fallbacks,
            # x-litellm-model-group) are not LLM provider headers and must not be
            # prefixed. Downstream consumers (proxy override, callers checking
            # whether a fallback happened) look up the bare key.
            processed_headers[k] = v
        else:
            additional_headers["{}-{}".format("llm_provider", k)] = v

    additional_headers = {
        **openai_headers,
        **processed_headers,
        **additional_headers,
    }
    request_id: Final = get_provider_request_id(response_headers)
    return {**additional_headers, **({"request-id": request_id} if request_id is not None else {})}


def preserve_upstream_non_openai_attributes(
    model_response: "ModelResponseStream", original_chunk: "ModelResponseStream"
):
    """
    Preserve non-OpenAI attributes from the original chunk.
    """
    # Access model_fields on the class, not the instance, to avoid Pydantic 2.11+ deprecation warnings
    expected_keys: Final = frozenset(type(model_response).model_fields) | frozenset({"usage"})
    candidate_keys: Final = tuple(
        key
        for key in (*type(original_chunk).model_fields, *(original_chunk.__pydantic_extra__ or {}))
        if key not in expected_keys
    )
    if not candidate_keys:
        return
    candidate_values: Final[tuple[tuple[str, object], ...]] = tuple(
        (
            key,
            cast(  # cast-ok: Pydantic extras are scalar-checked before assignment
                object,
                getattr(original_chunk, key),
            ),
        )
        for key in candidate_keys
    )
    if all(value is None or isinstance(value, (str, int, float, bool)) for _, value in candidate_values):
        _assign_attributes(model_response, candidate_values)
        return
    _assign_attributes(model_response, original_chunk.model_dump(include=frozenset(candidate_keys)).items())


def _assign_attributes(target: BaseModel, values: Iterable[tuple[str, object]]) -> None:
    for key, value in values:
        set_extra_attribute(target, key, value)


def safe_deep_copy(data):
    """
    Safe Deep Copy

    The LiteLLM request may contain objects that cannot be pickled/deep-copied
    (e.g., tracing spans, locks, clients).

    This helper deep-copies each top-level key independently; on failure keeps
    original ref
    """
    import copy

    import litellm

    if litellm.safe_memory_mode is True:
        return data

    litellm_parent_otel_span: object | None = None
    # Step 1: Remove the litellm_parent_otel_span
    litellm_parent_otel_span = None
    if isinstance(data, dict):
        # remove litellm_parent_otel_span since this is not picklable
        if "metadata" in data and "litellm_parent_otel_span" in data["metadata"]:
            litellm_parent_otel_span = data["metadata"].pop("litellm_parent_otel_span")
            data["metadata"]["litellm_parent_otel_span"] = "placeholder"
        if "litellm_metadata" in data and "litellm_parent_otel_span" in data["litellm_metadata"]:
            litellm_parent_otel_span = data["litellm_metadata"].pop("litellm_parent_otel_span")
            data["litellm_metadata"]["litellm_parent_otel_span"] = "placeholder"

    # Step 2: Per-key deepcopy with fallback
    if isinstance(data, dict):
        new_data = {}
        for k, v in data.items():
            try:
                new_data[k] = copy.deepcopy(v)
            except Exception:
                new_data[k] = v
    else:
        try:
            new_data = copy.deepcopy(data)
        except Exception:
            new_data = data

    # Step 3: re-add the litellm_parent_otel_span after doing a deep copy
    if isinstance(data, dict) and litellm_parent_otel_span is not None:
        if "metadata" in data and "litellm_parent_otel_span" in data["metadata"]:
            data["metadata"]["litellm_parent_otel_span"] = litellm_parent_otel_span
        if "litellm_metadata" in data and "litellm_parent_otel_span" in data["litellm_metadata"]:
            data["litellm_metadata"]["litellm_parent_otel_span"] = litellm_parent_otel_span
    return new_data


def independent_snapshot(
    data: dict,  # mutable-ok: caller-defined request-payload shape
) -> dict:  # mutable-ok: caller-defined request-payload shape
    """
    A copy of ``data`` whose top-level keys are deep-copied independently
    where possible -- always attempted, regardless of
    ``litellm.safe_memory_mode``. Unlike ``safe_deep_copy``, which can return
    the *original* object outright under that mode (defeating any isolation
    guarantee for every key, not just the ones that need it), this never
    skips copying wholesale.

    Real proxy requests carry ``data["litellm_logging_obj"]`` (a ``Logging``
    instance nesting a live OTel span with a real lock) by the time
    ``pre_call_hook`` runs, which can never be deep-copied. Any individual
    key that fails to deep-copy falls back to sharing its original
    reference, same crash tolerance as ``safe_deep_copy``'s own per-key
    fallback; callers needing true isolation (e.g. a guardrail's
    ``scan_raw_request`` snapshot) only depend on the keys that are plain,
    cleanly-copyable structures (``messages``/``input``,
    ``metadata``/``litellm_metadata``).
    """
    sanitized: Final = {
        key: (
            {
                inner_key: ("placeholder" if inner_key == "litellm_parent_otel_span" else inner_value)
                for inner_key, inner_value in value.items()
            }
            if key in ("metadata", "litellm_metadata") and isinstance(value, dict)
            else value
        )
        for key, value in data.items()
    }

    def _copied_value(key: str, sanitized_value: object) -> object:
        try:
            copied_value: Final = copy.deepcopy(sanitized_value)
        except Exception:  # noqa: BLE001  # any unpicklable value falls back to the original reference for this key only
            return data.get(key)
        original_value: Final = data.get(key)
        if (
            key in ("metadata", "litellm_metadata")
            and isinstance(copied_value, dict)
            and isinstance(original_value, dict)
            and "litellm_parent_otel_span" in original_value
        ):
            return {
                **copied_value,
                "litellm_parent_otel_span": original_value["litellm_parent_otel_span"],
            }
        return copied_value

    return {key: _copied_value(key, value) for key, value in sanitized.items()}


def filter_exceptions_from_params(data: object, max_depth: int = 20) -> Any:
    """
    Recursively filter out Exception objects and callable objects from dicts/lists.

    This is a defensive utility to prevent deepcopy failures when exception objects
    are accidentally stored in parameter dictionaries (e.g., optional_params).
    Also filters callable objects (functions) to prevent JSON serialization errors.
    Exceptions and callables should not be stored in params - this function removes them.

    Args:
        data: The data structure to filter (dict, list, or any other type)
        max_depth: Maximum recursion depth to prevent infinite loops

    Returns:
        Filtered data structure with Exception and callable objects removed, or None if the
        entire input was an Exception or callable
    """
    return _filter_exceptions_from_params(data, max_depth)


def _filter_exceptions_from_params(data: object, max_depth: int) -> object:
    if max_depth <= 0:
        return data

    # Skip exception objects
    if isinstance(data, Exception):
        return None
    # Skip callable objects (functions, methods, lambdas) but not classes (type objects)
    if callable(data) and not isinstance(data, type):
        return None
    # Skip known non-serializable object types (Logging, Router, etc.)
    obj_type_name: Final = type(data).__name__
    if obj_type_name in ["Logging", "LiteLLMLoggingObj", "Router"]:
        return None

    if isinstance(data, dict):
        result: Final[dict[str, object]] = {}
        for k, v in data.items():
            # Skip exception and callable values
            if isinstance(v, Exception) or (callable(v) and not isinstance(v, type)):
                continue
            try:
                filtered = _filter_exceptions_from_params(v, max_depth - 1)
                if filtered is not None:
                    result[k] = filtered
            except Exception:
                # Skip values that cause errors during filtering
                continue
        return result
    elif isinstance(data, list):
        result_list: Final[list[object]] = []
        for item in data:
            # Skip exception and callable items
            if isinstance(item, Exception) or (callable(item) and not isinstance(item, type)):
                continue
            try:
                filtered = _filter_exceptions_from_params(item, max_depth - 1)
                if filtered is not None:
                    result_list.append(filtered)
            except Exception:
                # Skip items that cause errors during filtering
                continue
        return result_list
    else:
        return data


def filter_internal_params(data: dict, additional_internal_params: set | None = None) -> dict:
    """
    Filter out LiteLLM internal parameters that shouldn't be sent to provider APIs.

    This removes internal/MCP-related parameters that are used by LiteLLM internally
    but should not be included in API requests to providers.

    Args:
        data: Dictionary of parameters to filter
        additional_internal_params: Optional set of additional internal parameter names to filter

    Returns:
        Filtered dictionary with internal parameters removed
    """
    if not isinstance(data, dict):
        return data

    # Known internal parameters that should never be sent to provider APIs
    internal_params: Final = {
        "skip_mcp_handler",
        "mcp_handler_context",
        "_skip_mcp_handler",
    }

    # Add any additional internal params if provided
    if additional_internal_params:
        internal_params.update(additional_internal_params)

    # Filter out internal parameters
    return {k: v for k, v in data.items() if k not in internal_params}


def redact_nested_match_and_regex_keys(
    payload: dict | list[Any] | str | None,
    keys: Collection[str] = ("match", "regex"),
) -> dict | list[Any] | str | None:
    """
    Deep-copy `payload` and replace every configured string field with "[REDACTED]"
    anywhere in nested dict/list structures.

    Used for guardrail spend/compliance logging so raw spans are not persisted.
    """
    if payload is None or isinstance(payload, str):
        return payload
    try:
        redacted: Final[dict | list[object] | str | None] = copy.deepcopy(payload)
    except Exception:
        return payload

    # Iterative traversal; `seen` guards against cyclic refs preserved by deepcopy.
    try:
        seen: Final[set] = set()
        stack: Final[list[object]] = [redacted]
        while stack:
            node = stack.pop()
            node_id = id(node)
            if node_id in seen:
                continue
            seen.add(node_id)
            if isinstance(node, dict):
                for key in keys:
                    if key in node:
                        node[key] = "[REDACTED]"
                stack.extend(node.values())
            elif isinstance(node, list):
                stack.extend(node)
    except Exception:
        return payload
    return redacted


RESPONSE_COST_HEADER: Final = "llm_provider-x-litellm-response-cost"
_NO_HEADERS: Final[Mapping[str, object]] = MappingProxyType({})


class _CarriesHiddenParams(Protocol):
    _hidden_params: dict[str, object]  # mutable-ok: the responses billed here keep hidden params in a plain dict

    @property
    def hidden_params(self) -> dict[str, object]: ...  # mutable-ok: API requires mutation

    @hidden_params.setter
    def hidden_params(self, hidden_params: dict[str, object]) -> None: ...  # mutable-ok: API requires mutation


_USAGE_BLOCK_ADAPTER: Final = TypeAdapter(Mapping[str, object])


def _usage_field(usage: object, name: str) -> object:
    if isinstance(usage, Mapping):
        return _USAGE_BLOCK_ADAPTER.validate_python(usage).get(name)
    return getattr(usage, name, None)


def finite_cost(value: object) -> float | None:
    if isinstance(value, bool) or not isinstance(value, int | float) or not math.isfinite(value):
        return None
    return float(value)


def single_log_line(value: object) -> str:
    return str(value).replace("\r", "").replace("\n", "")


def finite_reported_cost(value: object) -> float | None:
    cost: Final = finite_cost(value)
    if cost is None and isinstance(value, float):
        verbose_logger.warning("Ignoring a non-finite provider-reported cost %s", value)
    return cost


def _reported_cost_value(value: object) -> float | None:
    """A reported cost is a number, or a breakdown whose total lives under ``total_cost``."""
    raw: Final[object] = value
    if isinstance(value, Mapping):
        return finite_reported_cost(_usage_field(raw, "total_cost"))
    return finite_reported_cost(value)


def response_cost_in_hidden_params(response: _CarriesHiddenParams) -> float | None:
    additional_headers: Final[object] = response.hidden_params.get("additional_headers")
    if not isinstance(additional_headers, Mapping):
        return None
    return finite_reported_cost(_USAGE_BLOCK_ADAPTER.validate_python(additional_headers).get(RESPONSE_COST_HEADER))


def override_stamped_response_cost(response: _CarriesHiddenParams, cost: float) -> None:
    """Replace the cost an earlier builder stamped so every reader of the hidden params agrees with the header."""
    set_response_cost_in_hidden_params(response, cost)
    hidden_params: Final = response.hidden_params
    hidden_params["response_cost"] = cost


def chunk_usage(chunk: object) -> object:
    """Stream chunks reach the builders both as mappings and as ModelResponseStream objects."""
    if isinstance(chunk, Mapping):
        return _USAGE_BLOCK_ADAPTER.validate_python(chunk).get("usage")
    return getattr(chunk, "usage", None)


PROVIDERS_BILLED_FROM_THEIR_OWN_USAGE_FIELDS: Final = frozenset({"xai", "perplexity", "opencode_go"})


UPSTREAM_USAGE_COST: Final = "upstream_usage_cost"


def _numeric(value: object) -> float | None:
    return float(value) if isinstance(value, (int, float)) and not isinstance(value, bool) else None


def stamp_litellm_bill_on_usage(response: object, usage: object, bill: float) -> None:
    """Writes litellm's bill into ``usage.cost`` and the hidden ``response_cost`` cache, keeping the upstream's own
    ``usage.cost`` under ``upstream_usage_cost`` so a later pricing pass still bills the upstream's charge instead of
    reading litellm's bill back as if the upstream had reported it."""
    hidden: Final[object] = getattr(response, "_hidden_params", None)
    if isinstance(hidden, dict):
        hidden_params: Final = cast(dict[str, object], hidden)  # cast-ok: hidden params ride on the response as a dict
        upstream: Final = (
            hidden_params[UPSTREAM_USAGE_COST]
            if UPSTREAM_USAGE_COST in hidden_params
            else _numeric(getattr(usage, "cost", None))
        )
        hidden_params.update({"response_cost": bill, UPSTREAM_USAGE_COST: upstream})
    setattr(usage, "cost", bill)


def billed_usage_cost(response: object, custom_llm_provider: str | None) -> float | None:
    """The charge an OpenAI-compatible upstream reports in ``usage.cost``, skipped for providers billed from their own
    usage fields. Once litellm wrote its own bill into ``usage.cost`` (the stream builder and the Responses terminal
    event do), the upstream's figure is read from ``upstream_usage_cost`` instead."""
    if custom_llm_provider in PROVIDERS_BILLED_FROM_THEIR_OWN_USAGE_FIELDS:
        return None
    hidden: Final = as_str_mapping(getattr(response, "_hidden_params", None))
    cost: Final = (
        _numeric(hidden[UPSTREAM_USAGE_COST])
        if hidden is not None and UPSTREAM_USAGE_COST in hidden
        else provider_reported_usage_cost(_usage_field(response, "usage"), custom_llm_provider)
    )
    return cost if cost is not None and math.isfinite(cost) and cost >= 0 else None


_MESSAGES_REPORTED_COST_PROVIDERS: Final = frozenset({"opencode_go"})


def reports_native_messages_cost(custom_llm_provider: object) -> bool:
    """Whether a Messages upstream is one whose own reported cost litellm bills from instead of the price map."""
    return isinstance(custom_llm_provider, str) and custom_llm_provider in _MESSAGES_REPORTED_COST_PROVIDERS


def native_messages_reported_cost(usage: object, custom_llm_provider: object) -> float | None:
    """Only a Messages upstream known to price its own responses is trusted, every other one keeps the price map."""
    if not isinstance(custom_llm_provider, str) or not reports_native_messages_cost(custom_llm_provider):
        return None
    return provider_reported_usage_cost(usage, custom_llm_provider)


def provider_reported_usage_cost(usage: object, custom_llm_provider: str | None) -> float | None:
    """The request cost a provider states on its usage block, as a number or a breakdown with ``total_cost``.

    OpenCode Go reports the model's list price (peak hours and long-context tiers included) under
    ``usage.opencode.list_cost``, while its ``usage.cost`` is what hit the prepaid balance, 0 inside the plan.
    """
    if custom_llm_provider == "opencode_go":
        return _reported_cost_value(_usage_field(_usage_field(usage, "opencode"), "list_cost"))
    return _reported_cost_value(_usage_field(usage, "cost"))


def set_response_cost_in_hidden_params(response: _CarriesHiddenParams, cost: float | None) -> None:
    """Record a provider-reported cost where the cost calculator looks before the price map."""
    if cost is None:
        return
    hidden_params: Final = response.hidden_params
    additional_headers: Final[object] = hidden_params.get("additional_headers")
    merged: Final[dict[str, object]] = {  # mutable-ok: assigned into the plain-dict hidden params
        **(additional_headers if isinstance(additional_headers, Mapping) else _NO_HEADERS),
        RESPONSE_COST_HEADER: cost,
    }
    hidden_params["additional_headers"] = merged


_HIDDEN_PARAMS_ADAPTER: Final = TypeAdapter(Mapping[str, object])
_PROVIDER_HEADERS_ADAPTER: Final = TypeAdapter(Mapping[str, str])


def set_provider_response_headers_in_hidden_params(
    response: _CarriesHiddenParams, headers: httpx.Headers | Mapping[str, str]
) -> None:
    hidden_params: Final = response.hidden_params
    existing_additional_headers: Final[object] = hidden_params.get("additional_headers")
    raw_headers: Final[dict[str, str]] = dict(headers)  # mutable-ok: stored as the plain-dict hidden param
    additional_headers: Final[dict[str, object]] = {  # mutable-ok: assigned into the plain-dict hidden params
        **process_response_headers(raw_headers),
        **(existing_additional_headers if isinstance(existing_additional_headers, Mapping) else _NO_HEADERS),
    }
    hidden_params["headers"] = raw_headers
    hidden_params["additional_headers"] = additional_headers


def get_provider_response_headers_from_hidden_params(response: object) -> Mapping[str, str] | None:
    hidden_params: Final[object] = getattr(response, "_hidden_params", None)
    try:
        validated: Final = _HIDDEN_PARAMS_ADAPTER.validate_python(hidden_params)
        return _PROVIDER_HEADERS_ADAPTER.validate_python(validated.get("headers"))
    except ValidationError:
        return None
