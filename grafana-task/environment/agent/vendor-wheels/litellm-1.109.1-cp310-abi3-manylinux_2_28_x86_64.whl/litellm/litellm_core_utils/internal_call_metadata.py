"""Metadata a request forwards to the internal LLM sub-calls it triggers.

Internal features (the auto-router's classifier and embeddings, shadow eval's shadow and
judge calls) bill real provider spend that nobody typed a prompt for. That spend must land
on the same key/team/org/user as the request that caused it, so the sub-call carries the
caller's identity metadata, minus two things that must never be forwarded as-is:

* ``user_api_key_budget_reservation`` (and the reservation nested inside
  ``user_api_key_auth``) belongs to the parent completion. If a sub-call's cost callback
  sees it, that callback finalizes the reservation and the parent's own callback then
  skips incrementing the key/team budget counters, losing the parent's spend.
  ``user_api_key_auth`` itself is kept, sanitized, because model access-group filtering
  needs it.
* The sub-call is stamped with ``INTERNAL_CALL_ORIGIN_METADATA_KEY`` so its spend log row
  records that it is not traffic the caller sent.
"""

from __future__ import annotations

from collections.abc import Mapping
from types import MappingProxyType
from typing import Final

from litellm.constants import (
    INTERNAL_CALL_ORIGIN_METADATA_KEY,
    MANAGED_BACKGROUND_RESPONSE_METADATA_KEY,
    NON_INFERENCE_CALL_TYPES,
)
from litellm.litellm_core_utils.initialize_dynamic_callback_params import initialize_standard_callback_dynamic_params
from litellm.types.utils import (
    BACKGROUND_RESPONSE_COST_POLL_CALL_ORIGIN,
    BACKGROUND_RESPONSE_STATUS_POLL_CALL_ORIGIN,
    InternalCallOrigin,
)

BUDGET_RESERVATION_METADATA_KEYS: Final = frozenset({"user_api_key_budget_reservation"})

ITPM_RESERVED_KEY: Final = "_litellm_itpm_reserved"
OTPM_RESERVED_KEY: Final = "_litellm_otpm_reserved"
ITPM_CACHE_KEY: Final = "_litellm_itpm_cache_key"
OTPM_CACHE_KEY: Final = "_litellm_otpm_cache_key"
IO_TOKEN_RESERVATION_KEYS: Final = frozenset({ITPM_RESERVED_KEY, OTPM_RESERVED_KEY, ITPM_CACHE_KEY, OTPM_CACHE_KEY})

MODEL_ACCESS_GROUP_METADATA_KEY: Final = "user_api_key_matched_model_access_groups"
"""Where auth records the model access groups that authorized the request, for the spend writer.

The ``user_api_key`` prefix is load-bearing, not cosmetic: when a request carries both
``metadata`` and ``litellm_metadata``, ``get_litellm_metadata_from_kwargs`` returns the latter and
copies a key across only when ``user_api_key`` appears in its name."""

_USER_API_KEY_AUTH_KEY: Final = "user_api_key_auth"

FORWARDABLE_IDENTITY_METADATA_KEYS: Final = frozenset(
    {
        "user_api_key",
        "user_api_key_hash",
        "user_api_key_alias",
        "user_api_key_team_id",
        "user_api_key_org_id",
        "user_api_key_user_id",
        "user_api_key_end_user_id",
        _USER_API_KEY_AUTH_KEY,
    }
)
"""The caller-identity subset a detached sub-call needs to be attributed and
budget-checked like the request that spawned it. Everything else on the parent's metadata
(routing decision, guardrail state, logging payload) describes the parent call and would
be a lie on a sub-call that runs after it returned."""


def is_background_response(response: object) -> bool:
    """Whether a retrieved object is a response created with ``background=true``.

    Such a create returns ``status="queued"`` and no usage at all, so nothing has billed the
    job by the time anyone reads it back. Accepts the response as a mapping or a model,
    because the callers hold it in both shapes.
    """
    if isinstance(response, Mapping):
        return "background" in response and response["background"] is True
    return getattr(response, "background", None) is True


def requests_background(request_body: Mapping[str, object]) -> bool:
    return bool(request_body.get("background")) or is_background_response(request_body.get("extra_body"))


_RESPONSE_CREATE_CALL_TYPES: Final = frozenset({"responses", "aresponses"})


def _finished_response(response: object) -> object:
    wrapped: Final = response.get("response") if isinstance(response, Mapping) else getattr(response, "response", None)
    return response if wrapped is None else wrapped


def _may_be_unbilled(call_type: str | None, response: object) -> bool:
    if call_type in _RESPONSE_CREATE_CALL_TYPES:
        return is_background_response(_finished_response(response))
    return call_type in NON_INFERENCE_CALL_TYPES


def _is_managed_background_call(metadata: Mapping[str, object] | None) -> bool:
    return metadata is not None and metadata.get(MANAGED_BACKGROUND_RESPONSE_METADATA_KEY) is True


def is_unbilled_non_inference_call(
    call_type: str | None,
    metadata: Mapping[str, object] | None,
    response: object,
) -> bool:
    """A read/management route priced at zero, because the usage it reports belongs to the
    call that created the object it just read.

    A background response is the exception, since its create billed nothing. When the proxy
    tracks it as a managed object, the read is marked with
    ``MANAGED_BACKGROUND_RESPONSE_METADATA_KEY`` and stays free, because the one billing event
    the proxy logs from the finished response, stamped with
    ``BACKGROUND_RESPONSE_COST_POLL_CALL_ORIGIN``, bills the job. A streamed background create
    the proxy tracks carries the same marker and is free for the same reason. Any other
    read of a background response (the SDK, a proxy without a database) is the only place its
    spend is ever visible, so it prices normally.
    """
    if not _may_be_unbilled(call_type, response):
        return False
    if call_type in _RESPONSE_CREATE_CALL_TYPES:
        return _is_managed_background_call(metadata)
    origin: Final = metadata.get(INTERNAL_CALL_ORIGIN_METADATA_KEY) if metadata is not None else None
    if origin == BACKGROUND_RESPONSE_COST_POLL_CALL_ORIGIN:
        return False
    if not is_background_response(_finished_response(response)):
        return True
    return origin == BACKGROUND_RESPONSE_STATUS_POLL_CALL_ORIGIN or _is_managed_background_call(metadata)


def is_unbilled_non_inference_call_from_params(
    call_type: str | None,
    litellm_params: Mapping[str, object] | None,
    response: object,
) -> bool:
    """:func:`is_unbilled_non_inference_call` for callers holding raw ``litellm_params``.

    The call-type and background tests run first so that inference traffic, which is every
    request in a normal workload, never pays for the metadata merge behind it.
    """
    if not _may_be_unbilled(call_type, response):
        return False
    from litellm.litellm_core_utils.litellm_logging import StandardLoggingPayloadSetup

    metadata: Final = (
        StandardLoggingPayloadSetup.merge_litellm_metadata(litellm_params) if litellm_params is not None else None
    )
    return is_unbilled_non_inference_call(call_type, metadata, response)


def sanitize_user_api_key_auth(auth: object) -> object:
    """Copy of the auth object with its budget reservation removed; the cost callback
    falls back to reading the reservation from inside the auth object."""
    if isinstance(auth, dict):
        return {k: v for k, v in auth.items() if k != "budget_reservation"}
    reservation: Final[object] = getattr(auth, "budget_reservation", None)
    model_copy: Final[object] = getattr(auth, "model_copy", None)
    if reservation is not None and callable(model_copy):
        return model_copy(update={"budget_reservation": None})
    return auth


def without_budget_reservation(
    parent_metadata: Mapping[str, object],
) -> dict[str, object]:  # mutable-ok: SDK metadata kwarg
    """Parent metadata minus the admission reservation, also inside ``user_api_key_auth``."""
    return {
        k: sanitize_user_api_key_auth(v) if k == _USER_API_KEY_AUTH_KEY else v
        for k, v in parent_metadata.items()
        if k not in BUDGET_RESERVATION_METADATA_KEYS
    }


def forwarded_internal_call_metadata(
    parent_metadata: Mapping[str, object] | None,
    call_origin: InternalCallOrigin,
) -> dict[str, object]:  # mutable-ok: SDK metadata kwarg
    """Parent metadata, minus its budget reservation, stamped with the sub-call's origin.

    For sub-calls made inside the parent request (classifier, embeddings), where the
    parent's full context still describes the call being made.
    """
    if not parent_metadata:
        return {}
    return without_budget_reservation(parent_metadata) | {INTERNAL_CALL_ORIGIN_METADATA_KEY: call_origin}


def parent_session_kwargs(request_kwargs: Mapping[str, object] | None) -> Mapping[str, str]:
    kwargs: Final = request_kwargs or MappingProxyType({})
    return MappingProxyType(
        {k: v for k in ("litellm_session_id", "litellm_trace_id") if isinstance(v := kwargs.get(k), str)}
    )


def effective_turn_off_message_logging(request_kwargs: Mapping[str, object] | None) -> bool | None:
    return initialize_standard_callback_dynamic_params(dict(request_kwargs) if request_kwargs else None).get(
        "turn_off_message_logging"
    )


def sanitized_forwardable_call_metadata(
    parent_metadata: Mapping[str, object],
    call_origin: InternalCallOrigin,
) -> dict[str, object]:  # mutable-ok: SDK metadata kwarg
    """Just the caller's identity, stamped with the sub-call's origin.

    For sub-calls detached from the parent request (shadow eval), which outlive it and
    must not inherit per-request state such as its routing decision or logging payload.
    """
    identity: Final = {k: v for k, v in parent_metadata.items() if k in FORWARDABLE_IDENTITY_METADATA_KEYS}
    return without_budget_reservation(identity) | {INTERNAL_CALL_ORIGIN_METADATA_KEY: call_origin}
