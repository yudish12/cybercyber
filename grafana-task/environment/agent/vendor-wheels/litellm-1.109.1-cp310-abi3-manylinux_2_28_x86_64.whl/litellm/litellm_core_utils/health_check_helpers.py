"""
Helper functions for health check calls.
"""

import base64
import itertools
import re
from collections.abc import Awaitable, Callable, Mapping
from types import MappingProxyType
from typing import TYPE_CHECKING, Final, Literal

from litellm.llms.base_llm.ocr.transformation import DocumentType
from litellm.rust_bridge import runtime
from litellm.rust_bridge.ocr.entrypoints import NATIVE_OCR_HEALTH_CHECK_DOCUMENT
from litellm.types.utils import LIST_BATCHES_SUPPORTED_PROVIDERS

if TYPE_CHECKING:
    from litellm.litellm_core_utils.litellm_logging import Logging
    from litellm.types.utils import ImageResponse


# Minimal image for health checks - base64 encoded 512x512 blue circle on a white background PNG
TEST_IMAGE_BASE64 = "iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAIAAAB7GkOtAAAJk0lEQVR42u3VQREAIRADwVWCOmTjBVzwSLorCri6nbkAVBpPACAAAAgAAAIAgAAAIAAACAAAAgCAAAAgAAAIAAACAIAAACAAAAgAAAIAgAAAIAAACAAAAgCAAAAgAAAIAAACACAAAAgAAAIAgAAAIAAACAAAAgCAAAAgAAAIAAACAIAAACAAAAgAAAIAgAAAIAAACAAAAgCAAAAgAAAIAAACACAAAAgAAAIAgAAAIAAACAAAAgCAAAAgAAAIAAACAIAAACAAAAgAAAIAgAAAIAAACAAAAgCAAAAgAAAIAAACAIAAAAgAAAIAgAAAIAAACAAAAgCAAAAgAAAIAAACAIAAACAAAAgAAAIAgAAAIAAACAAAAgCAAAAgAAAIAAACAIAAAAgAAAIAZdY+HgEBgIRr/meeGgGA8EMvDAgAuPh6gACAi68HCAA4+mKAAICjLwYIALj7SoAAgLuvBAgA7r4pAQKAu29KgADg7psSIAA4/SYDCADuvikBAoDTbzKAAOD0mwwgADj9JgMIAE6/yQACgNNvMoAA4PSbDCAAOP0mAwgATr/JAAKA668BIAA4/TKAAOD0mwwgALj+pgEIAE6/yQACgOtvGoAA4PSbDCAAuP6mAQgATr/JAAKA628agADg9JsMIAC4/qYBCACuv2kAAoDrbxqAAOD0mwwgALj+pgEIAK6/aQACgOtvGoAA4PqbBiAArr+ZBiAATr+ZDCAArr+ZBiAArr+ZBiAArr+ZBiAArr+ZBggArr+ZBggArr+ZBggArr+ZBggArr+ZBggArr+ZBggArr+ZBggAAmAmAAKA62+mAQKA62+mAQKA62/m1xYAXH/TAAQA1980AAHA9TcNQAAEwEwAEADX30wDEADX30wDEADX30wDEADX30wDEAABMBMABMD1N9MABMD1N9MABEAAzAQAAXD9zTQAAXD9zTRAABAAMwEQAFx/Mw0QAFx/Mw0QAATATAAEANffTAMEANffTAMEAAEwEwABwPU30wABQADMBEAAXH8z0wABcP3NTAMEQADMTAAEwPU3Mw0QAAEwMwEQANffTAMQAAEwEwAEwPU30wAEQADMBAABcP3NNAABEAAzAUAAXH8zDUAABMBMABAA199MAwQAATATAAHA9TfTAAFAAMwEQABw/c00QAAQADMBEAAEwEwABMD1NzMNEAABMDMBEADX38w0QAAEwMwEQAAEwMwEQABcfzPTAAEQADMTAAEQADMTAAFw/c1MAwRAAMxMAARAAMxMAATA9TczDRAAATATAARAAMwEAAFw/c00AAEQADMBQAAEwEwAEADX30wDBAABMBMAAUAAzARAABAAMwEQAFx/Mw0QAAEwMwEQAAEwMwEQAAEwMwEQANffzDRAAATAzARAAATAzARAAATAzARAAATAzARAAFx/M9MAARAAMxMAARAAMxMAARAAMxMAARAAMxMAAXD9zUwDBEAAzEwABEAAzAQAARAAMwFAAATATAAQAAEwEwABQADMBEAAEAAzARAAXH8zDRAAATAzARAAATAzARAAATAzARAAATAzARAAATAzARAAATAzARAAATAzARAAATAzARAAATAzARAAATAzARAAATAzARAAATAzARAAATAzARAAATAzARAAATAzARAAATAzARAA19/MNEAANMDM9UcABMBMABAAATATAAHwBAJgJgACgACYCYAAIABmAiAA+IvMBEAABMDMBEAABMDMBEAABMDMBEAABMDMBEAABMDMBEAABMDMBEAABMDMBEAABMDMBEAABMDMBEAABMDMBEAANMDMXH8BEAAzEwABEAAzEwABEAAzEwABEAAzEwABEAAzEwABEAAzAUAABMBMABAADTBz/REAATATAAFAAMwEQAAQADMBEAAEwEwABAANMHP9BUAAzEwABEAAzEwABEAAzEwABEAAzEwABEADzMz1FwABMDMBEAABMDMBEAABMDMBEAANMDPXXwAEwMwEQAAEwMwEQAAEwMwEQAA0wMxcfwEQADMTAAEQADMBQAA0wMz1RwAEwEwAEAABMBMABEADzFx/AUAAzARAABAAMwEQADTAzPUXAATATAAEAAEwEwABQAPMXH8BEAAzEwABEAAzEwAB0AAzc/0FQADMTAAEQAPMzPUXAAEwMwEQAAEwMwEQAA0wM9dfAATAzARAADTAzFx/ARAAMwFAADTAzPVHAATATAAQAA0wc/0RAAEwEwAEQAPMXH8EQADMBAAB0AAz118AEAAzARAANMDM9RcABMBMAAQADTBz/QUAATATAAFAA8xcfwFAA8xcfwFAAMwEQADQADPXXwAEwMwEQAA0wMxcfwHQADNz/QVAAMxMAARAA8xcfwRAA8xcfwRAAMwEAAHQADPXHwHQADPXHwEQADMBQAA0wMz1RwA0wMz1RwAEwEwAEAANMHP9BQANMHP9BQANMHP9BQANMHP9BQABMBMAAUADzFx/AUADzFx/AUADzFx/AUADzFx/AUADzFx/AUADzPVHABAAEwAEAA0w1x8BQAPM9UcA0ABz/REANMBcfwQADTDXHwHQADPXHwHQADPXHwHQADPXHwHQADPXHwHQADPXHwGQATOnHwHQADPXHwHQADPXXwDQADPXXwDQADPXXwDQADPXXwCQAXP6EQA0wFx/BAANMNcfAUADzPVHAJABc/oRADTAXH8EABkwpx8BQAPM9UcAkAFz+hEANMBcfwQAGTCnHwFAA8z1RwCQAXP6EQBkwJx+BAANMNcfAUAGzOlHAJABc/oRAGTA6QcBQAacfhAAZMDpRwBABpx+BABkwOlHAEAGnH4EAJTA3UcAQAacfgQAlMDdRwBACdx9BACUwN1HAEAJ3H0EAJTA3UcAQAwcfQQAmmLgsyIA0NIDHw4BgJYe+DQIAISHwVMjAJDQDI+AAAAgAAAIAAACAIAAACAAAAgAAAIAgAAAIAAACAAAAgCAAAAgAAAIAAACAIAAACAAAAgAAAIAgAAAIAAACACAAAAgAAAIAAACAIAAACAAAAgAAAIAgAAAIAAACAAAAgCAAAAgAAAIAAACAIAAACAAAAgAAAIAgAAAIAAACAAAAgAgAAAIAAACAIAAACAAAAgAAAIAgAAAIAAACAAAAgCAAAAgAAAIAAACAIAAACAAAAgAAAIAgAAAIAAACAAAAgAgAAAIAAACAIAAACAAAAgAAAIAgAAAIAAACAAAAgCAAAAgAAAIAAACAIAAACAAAAgAAAIAgAAAIAAACAAAAgCAAAAIAABNHpialFcmLajuAAAAAElFTkSuQmCC"


IMAGE_EDIT_HEALTH_CHECK_PROMPT: Final = (
    "Add a small yellow star in the top right corner of this simple drawing of a blue circle on a white background"
)

ANTHROPIC_MESSAGES_HEALTH_CHECK_MAX_TOKENS: Final = 16
WILDCARD_HEALTH_CHECK_SERVED_MODEL_COUNT: Final = 2
WILDCARD_HEALTH_CHECK_PROVIDER_MODEL_COUNT: Final = 3
BEDROCK_ANY_MODEL_ROUTES: Final = frozenset({"converse", "invoke"})
EXTRACTION_HEALTH_CHECK_FIELDS: Final[Mapping[str, Mapping[str, str]]] = MappingProxyType(
    {"reachable": MappingProxyType({"type": "text", "instructions": "Any word from the text"})}
)


def native_health_check_mode(
    model: str, custom_llm_provider: str | None
) -> Literal["anthropic_messages", "realtime"] | None:
    if custom_llm_provider == "soniox":
        from litellm.llms.soniox.common_utils import soniox_health_check_mode

        return soniox_health_check_mode(model)
    if custom_llm_provider != "bedrock_mantle":
        return None
    from litellm.llms.bedrock_mantle.common_utils import mantle_health_check_mode

    return mantle_health_check_mode(model)


def _cost_map_mode(model: str) -> str | None:
    import litellm
    from litellm.litellm_core_utils.health_check_utils import OPTIONAL_STR

    return OPTIONAL_STR.validate_python(litellm.model_cost.get(model, {}).get("mode"))


def default_health_check_mode(requested_model: str, model: str, custom_llm_provider: str) -> str:
    return (
        native_health_check_mode(model=model, custom_llm_provider=custom_llm_provider)
        or _cost_map_mode(requested_model)
        or _cost_map_mode(model)
        or "chat"
    )


def get_image_file_for_health_check() -> bytes:
    """Return the image used for health checks."""
    return base64.b64decode(TEST_IMAGE_BASE64)


def _decisions_health_check_questions(model: str, custom_llm_provider: str) -> Mapping[str, Mapping[str, object]]:
    import litellm
    from litellm.llms.base_llm.decisions.transformation import BaseDecisionsConfig
    from litellm.utils import ProviderConfigManager

    provider: Final = next((member for member in litellm.LlmProviders if member.value == custom_llm_provider), None)
    config: Final = (
        None
        if provider is None
        else ProviderConfigManager.get_provider_decisions_config(model=model, provider=provider)
    )
    questions: Final = BaseDecisionsConfig.health_check_questions if config is None else config.health_check_questions
    return {name: dict(question) for name, question in questions.items()}


def _ocr_health_check_document(model: str, custom_llm_provider: str) -> DocumentType:
    native: Final = NATIVE_OCR_HEALTH_CHECK_DOCUMENT.load()
    if native is None:
        raise runtime.NoPythonImplementationError(
            "ocr health check documents are resolved by the Rust extension, which is not available"
        )
    return native(model, custom_llm_provider)


def _provider_base_model(custom_llm_provider: str, model: str) -> str | None:
    from litellm.types.utils import LlmProviders
    from litellm.utils import ProviderConfigManager

    try:
        model_info: Final = ProviderConfigManager.get_provider_model_info(
            model=None, provider=LlmProviders(custom_llm_provider)
        )
        return None if model_info is None else model_info.get_base_model(model)
    except (ValueError, NotImplementedError):
        return None


def _is_route_segment(custom_llm_provider: str, segment: str, model_after_segment: str) -> bool:
    if custom_llm_provider == "bedrock":
        from litellm.llms.bedrock.common_utils import get_all_bedrock_regions

        return segment in BEDROCK_ANY_MODEL_ROUTES or segment in get_all_bedrock_regions()
    base_model: Final = _provider_base_model(custom_llm_provider, f"{segment}/{model_after_segment}")
    return base_model is not None and not base_model.startswith(f"{segment}/")


def wildcard_health_check_models(wildcard: str, custom_llm_provider: str) -> tuple[str, ...]:
    from litellm.litellm_core_utils.llm_request_utils import rank_chat_models_from_llm_provider
    from litellm.litellm_core_utils.pattern_match_deployments import PatternMatchRouter

    provider_prefix: Final = f"{custom_llm_provider}/"
    segments: Final = wildcard.removeprefix(provider_prefix).split("/")
    route_segments: Final = tuple(
        itertools.takewhile(
            lambda segment_index: _is_route_segment(
                custom_llm_provider, segments[segment_index], "/".join(segments[segment_index + 1 :])
            ),
            range(len(segments) - 1),
        )
    )
    route_prefix: Final = "".join(f"{segments[segment_index]}/" for segment_index in route_segments)
    model_regex: Final = re.compile(PatternMatchRouter().pattern_to_regex("/".join(segments[len(route_segments) :])))
    ranked_model_ids: Final = tuple(
        (ranked_model.model.removeprefix(provider_prefix), ranked_model)
        for ranked_model in rank_chat_models_from_llm_provider(custom_llm_provider)
    )
    served_model_ids: Final = sorted(
        (ranked for ranked in ranked_model_ids if model_regex.fullmatch(ranked[0])),
        key=lambda ranked: (ranked[1].is_past_deprecation_date, ranked[1].route_rank, ranked[1].cost, ranked[0]),
    )
    served_probes: Final = itertools.islice(
        dict.fromkeys(f"{provider_prefix}{route_prefix}{model_id}" for model_id, _ in served_model_ids),
        WILDCARD_HEALTH_CHECK_SERVED_MODEL_COUNT,
    )
    provider_probes: Final = (
        f"{provider_prefix}{model_id}" for model_id, _ in ranked_model_ids[:WILDCARD_HEALTH_CHECK_PROVIDER_MODEL_COUNT]
    )
    return tuple(dict.fromkeys((*served_probes, *provider_probes)))


class HealthCheckHelpers:
    @staticmethod
    async def ahealth_check_wildcard_models(
        model: str,
        custom_llm_provider: str,
        model_params: dict,
        litellm_logging_obj: "Logging",
    ) -> dict:
        from litellm import acompletion

        probe_models: Final = wildcard_health_check_models(wildcard=model, custom_llm_provider=custom_llm_provider)
        if len(probe_models) == 0:
            raise Exception(
                f"Unable to health check wildcard model {model} for provider {custom_llm_provider}: the cost map has "
                "no chat model for this provider. Set model_info.health_check_model to a model this wildcard serves"
            )
        model_params["model"] = probe_models[0]
        model_params["litellm_logging_obj"] = litellm_logging_obj
        model_params["fallbacks"] = list(probe_models[1:]) or None
        model_params["max_tokens"] = model_params.get("max_tokens", 16)  # GPT-5 models require max_output_tokens >= 16
        await acompletion(**model_params)
        return {}

    @staticmethod
    def update_model_params_with_health_check_tracking_information(
        model_params: dict,
    ) -> dict:
        """
        Updates the health check model params with tracking information.

        The following is added at this stage:
            1. `tags`: This helps identify health check calls in the DB.
            2. `user_api_key_auth`: This helps identify health check calls in the DB.
                We need this since the DB requires an API Key to track a log in the SpendLogs Table
        """
        from litellm.proxy.litellm_pre_call_utils import LiteLLMProxyRequestSetup
        from litellm.types.proxy.auth.user_api_key_auth import UserAPIKeyAuth

        _metadata_variable_name: Final = "litellm_metadata"
        litellm_metadata: Final = HealthCheckHelpers._get_metadata_for_health_check_call()
        model_params[_metadata_variable_name] = litellm_metadata
        model_params = LiteLLMProxyRequestSetup.add_user_api_key_auth_to_request_metadata(
            data=model_params,
            user_api_key_dict=UserAPIKeyAuth.get_litellm_internal_health_check_user_api_key_auth(),
            _metadata_variable_name=_metadata_variable_name,
        )
        return model_params

    _update_model_params_with_health_check_tracking_information = (
        update_model_params_with_health_check_tracking_information
    )

    @staticmethod
    def _get_metadata_for_health_check_call():
        """
        Returns the metadata for the health check call.
        """
        from litellm.constants import LITTELM_INTERNAL_HEALTH_SERVICE_ACCOUNT_NAME

        return {
            "tags": [LITTELM_INTERNAL_HEALTH_SERVICE_ACCOUNT_NAME],
        }

    @staticmethod
    async def _batch_health_check(
        custom_llm_provider: str,
        model_params: dict,
        filtered_model_params: dict,
    ) -> dict:
        """
        Health check for batch mode.

        Calls list_batches for providers that support it. For all other providers (e.g. bedrock)
        the batch API surface doesn't include list_batches, so we fall back to acompletion to
        verify connectivity and credential validity instead.
        """
        import litellm

        logging_obj: Final = filtered_model_params.get("litellm_logging_obj")
        if logging_obj is not None:
            api_base: Final = filtered_model_params.get("api_base")
            logging_obj.update_from_kwargs(
                kwargs=filtered_model_params,
                model=filtered_model_params.get("model"),
                user=None,
                optional_params={},
                litellm_params={"api_base": api_base} if api_base else None,
            )

        if custom_llm_provider not in LIST_BATCHES_SUPPORTED_PROVIDERS:
            return await litellm.acompletion(**model_params)
        return await litellm.alist_batches(**{**filtered_model_params, "custom_llm_provider": custom_llm_provider})

    @staticmethod
    async def _image_edit_health_check(edit_request: Callable[[], Awaitable["ImageResponse"]]) -> "ImageResponse":
        import litellm

        try:
            return await edit_request()
        except litellm.BadRequestError as e:
            if isinstance(e, litellm.ContentPolicyViolationError) or "moderation_blocked" in str(e):
                return litellm.ImageResponse()
            raise

    @staticmethod
    def get_mode_handlers(
        model: str,
        custom_llm_provider: str,
        model_params: dict,
        prompt: str | None = None,
        input: list | None = None,
    ) -> dict[
        Literal[
            "chat",
            "completion",
            "embedding",
            "audio_speech",
            "audio_transcription",
            "image_generation",
            "image_edit",
            "video_generation",
            "rerank",
            "realtime",
            "batch",
            "responses",
            "anthropic_messages",
            "ocr",
            "decisions",
            "extraction",
        ],
        Callable,
    ]:
        """
        Returns a dictionary of mode handlers for health check calls.

        Mode Handlers are Callables that need to be run for execution of the health check call.

        Args:
            model: The model name
            custom_llm_provider: The LLM provider
            model_params: The model parameters
            prompt: Optional prompt for health check
            input: Optional input for health check

        Returns:
            Dictionary mapping mode names to their handler functions
        """
        import litellm
        from litellm.litellm_core_utils.audio_utils.utils import (
            get_audio_file_for_health_check,
        )
        from litellm.litellm_core_utils.health_check_utils import (
            DECISIONS_CALL_PARAMS,
            EXTRACTION_CALL_PARAMS,
            _filter_model_params,
        )
        from litellm.realtime_api.main import realtime_health_check

        return {
            "chat": lambda: litellm.acompletion(
                **model_params,
            ),
            "completion": lambda: litellm.atext_completion(
                **_filter_model_params(model_params=model_params),
                prompt=prompt or "test",
            ),
            "embedding": lambda: litellm.aembedding(
                **_filter_model_params(model_params=model_params),
                input=input or ["test"],
            ),
            "audio_speech": lambda: litellm.aspeech(
                **{
                    **_filter_model_params(model_params=model_params),
                    **({"voice": "alloy"} if "voice" not in _filter_model_params(model_params=model_params) else {}),
                },
                input=prompt or "test",
            ),
            "audio_transcription": lambda: litellm.atranscription(
                **_filter_model_params(model_params=model_params),
                file=get_audio_file_for_health_check(),
            ),
            "image_generation": lambda: litellm.aimage_generation(
                **_filter_model_params(model_params=model_params),
                prompt=prompt,
            ),
            "image_edit": lambda: HealthCheckHelpers._image_edit_health_check(
                edit_request=lambda: litellm.aimage_edit(
                    **_filter_model_params(model_params=model_params),
                    image=get_image_file_for_health_check(),
                    prompt=IMAGE_EDIT_HEALTH_CHECK_PROMPT,
                ),
            ),
            "video_generation": lambda: litellm.avideo_generation(
                **_filter_model_params(model_params=model_params),
                prompt=prompt or "test video generation",
            ),
            "rerank": lambda: litellm.arerank(
                **_filter_model_params(model_params=model_params),
                query=prompt or "",
                documents=["my sample text"],
            ),
            "realtime": lambda: realtime_health_check(
                model=model,
                custom_llm_provider=custom_llm_provider,
                api_base=model_params.get("api_base", None),
                api_key=model_params.get("api_key", None),
                api_version=model_params.get("api_version", None),
                model_params=model_params,
            ),
            "batch": lambda: HealthCheckHelpers._batch_health_check(
                custom_llm_provider=custom_llm_provider,
                model_params=model_params,
                filtered_model_params=_filter_model_params(model_params=model_params),
            ),
            "responses": lambda: litellm.aresponses(
                **_filter_model_params(model_params=model_params),
                input=prompt or "test",
            ),
            "anthropic_messages": lambda: litellm.anthropic_messages(
                **{
                    "max_tokens": ANTHROPIC_MESSAGES_HEALTH_CHECK_MAX_TOKENS,
                    "messages": [{"role": "user", "content": prompt or "test"}],
                    **model_params,
                }
            ),
            "ocr": lambda: litellm.aocr(
                **_filter_model_params(model_params=model_params),
                document=_ocr_health_check_document(model=model, custom_llm_provider=custom_llm_provider),
            ),
            "decisions": lambda: litellm.asystemone(
                **DECISIONS_CALL_PARAMS.validate_python(
                    {
                        "state": prompt or "health check",
                        "questions": _decisions_health_check_questions(
                            model=model, custom_llm_provider=custom_llm_provider
                        ),
                        **_filter_model_params(model_params=model_params),
                    }
                )
            ),
            "extraction": lambda: litellm.aextraction(
                **EXTRACTION_CALL_PARAMS.validate_python(
                    {
                        "state": prompt or "health check",
                        "fields": EXTRACTION_HEALTH_CHECK_FIELDS,
                        **_filter_model_params(model_params=model_params),
                    }
                )
            ),
        }
