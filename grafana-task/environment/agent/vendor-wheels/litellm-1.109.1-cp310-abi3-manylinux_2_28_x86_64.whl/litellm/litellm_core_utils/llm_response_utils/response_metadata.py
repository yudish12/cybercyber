import datetime
from collections.abc import Mapping
from functools import reduce
from typing import Final

import httpx
from pydantic import TypeAdapter, ValidationError

from litellm.constants import LITELLM_DETAILED_TIMING
from litellm.litellm_core_utils.core_helpers import get_litellm_metadata_from_kwargs, process_response_headers
from litellm.litellm_core_utils.llm_response_utils.get_api_base import get_api_base
from litellm.litellm_core_utils.logging_utils import LiteLLMLoggingObject
from litellm.types.utils import (
    EmbeddingResponse,
    HiddenParams,
    ModelResponse,
    TranscriptionResponse,
)


def _timing_window_start(
    start_time: datetime.datetime, logging_obj: LiteLLMLoggingObject
) -> tuple[datetime.datetime, bool]:
    received_at: Final = get_litellm_metadata_from_kwargs(logging_obj.model_call_details).get("litellm_received_at")
    if isinstance(received_at, datetime.datetime):
        return received_at, True
    return start_time, False


def response_ms_since_logging_start(logging_obj: LiteLLMLoggingObject) -> float | None:
    reported_ms: Final = logging_obj.response_timing_metrics.get("_response_ms")
    if reported_ms is None:
        return None
    logging_start: Final = logging_obj.start_time
    window_start: Final = _timing_window_start(logging_start, logging_obj)[0]
    return reported_ms - max(0.0, logging_start.timestamp() - window_start.timestamp()) * 1000


def _union_duration_ms(windows: object, lower: float, upper: float) -> float | None:
    if not isinstance(windows, (list, tuple)):
        return None
    clipped: Final[tuple[tuple[float, float], ...]] = tuple(
        (max(lower, float(window[0])), min(upper, float(window[1])))
        for window in windows
        if isinstance(window, (list, tuple))
        and len(window) == 2
        and isinstance(window[0], (int, float))
        and isinstance(window[1], (int, float))
        and max(lower, float(window[0])) < min(upper, float(window[1]))
    )
    if not clipped:
        return None

    ordered: Final[tuple[tuple[float, float], ...]] = tuple(sorted(clipped))

    def merge_window(
        merged: tuple[tuple[float, float], ...], current: tuple[float, float]
    ) -> tuple[tuple[float, float], ...]:
        if not merged or current[0] > merged[-1][1]:
            return (*merged, current)
        return (*merged[:-1], (merged[-1][0], max(merged[-1][1], current[1])))

    merged: Final[tuple[tuple[float, float], ...]] = reduce(merge_window, ordered, ())
    return sum(end - start for start, end in merged) * 1000


def response_timing_metrics(
    start_time: datetime.datetime,
    end_time: datetime.datetime,
    logging_obj: LiteLLMLoggingObject,
    include_overhead: bool = True,
) -> Mapping[str, float]:
    """``_response_ms`` for the window starting at proxy receive time when stamped, else ``start_time``.

    On a cache hit the overhead is the total minus the cache read; otherwise it is the total minus
    the provider call (``llm_api_duration_ms``). It is omitted when neither duration was recorded,
    and when ``include_overhead`` is False because the two durations cover different windows.
    """
    timing_window: Final = _timing_window_start(start_time, logging_obj)
    window_start: Final = timing_window[0]
    receive_anchored: Final = timing_window[1]
    total_response_time_ms: Final = (end_time.timestamp() - window_start.timestamp()) * 1000
    if not include_overhead:
        return {"_response_ms": total_response_time_ms}
    caching_details: Final = logging_obj.caching_details
    cache_duration_ms: Final = (
        caching_details.get("cache_duration_ms")
        if caching_details is not None and caching_details.get("cache_hit") is True
        else None
    )
    metadata: Final[Mapping[str, object]] = get_litellm_metadata_from_kwargs(logging_obj.model_call_details)
    llm_api_duration_ms: Final = logging_obj.model_call_details.get("llm_api_duration_ms")
    if cache_duration_ms is not None:
        overhead_ms: float | None = total_response_time_ms - cache_duration_ms
    elif llm_api_duration_ms is not None:
        provider_duration_ms: Final[float | None] = (
            _union_duration_ms(
                metadata.get("llm_api_timing_windows"),
                window_start.timestamp(),
                end_time.timestamp(),
            )
            if receive_anchored
            else None
        )
        effective: Final = provider_duration_ms if provider_duration_ms is not None else llm_api_duration_ms
        overhead_ms = round(total_response_time_ms - effective, 4) if isinstance(effective, (int, float)) else None
    else:
        overhead_ms = None
    if overhead_ms is None:
        return {"_response_ms": total_response_time_ms}
    return {"_response_ms": total_response_time_ms, "litellm_overhead_time_ms": overhead_ms}


_HIDDEN_PARAMS_DICT: Final = TypeAdapter(dict[str, object])


def _hidden_params_mapping(hidden_params: object) -> Mapping[str, object]:
    try:
        return _HIDDEN_PARAMS_DICT.validate_python(hidden_params)
    except ValidationError:
        return {}


def _existing_provider_response_model(result: object) -> str | None:
    """The pricing model a response already carries, like the decisions path sets, wins over the response model."""
    hidden_params: Final[object] = getattr(result, "_hidden_params", None)
    carried: Final[object] = _hidden_params_mapping(hidden_params).get("provider_response_model") or getattr(
        hidden_params, "provider_response_model", None
    )
    return carried if isinstance(carried, str) and carried else None


def _provider_response_model(result: object) -> str | None:
    """The model the provider answered with, kept because the proxy later rewrites ``result.model`` to the alias the
    client asked for and cost-map lookups for the standard logging payload would otherwise miss."""
    model: Final = getattr(result, "model", None) if isinstance(result, ModelResponse) else None
    return model if isinstance(model, str) and model else None


class ResponseMetadata:
    """
    Handles setting and managing `_hidden_params`, `response_time_ms`, and `litellm_overhead_time_ms` for LiteLLM responses
    """

    def __init__(self, result: object):
        self.result = result
        self._hidden_params: HiddenParams | dict = getattr(result, "_hidden_params", {}) or {}

    @property
    def supports_response_time(self) -> bool:
        """Check if response type supports timing metrics"""
        return isinstance(self.result, (ModelResponse, EmbeddingResponse, TranscriptionResponse))

    def set_hidden_params(
        self,
        logging_obj: LiteLLMLoggingObject,
        model: str | None,
        kwargs: dict,
        cache_hit: bool | None = None,
    ) -> None:
        """Set hidden parameters on the response.

        ``cache_hit`` is passed for a response served from the cache: ``logging_obj`` only
        learns of the hit later, in the success handler, so its cost calculator would
        otherwise price the cached response as a fresh call.
        """

        ## ADD OTHER HIDDEN PARAMS
        model_info: Final = kwargs.get("model_info", {}) or {}
        model_id: Final = model_info.get("id", None)
        new_params: Final = {
            "litellm_call_id": getattr(logging_obj, "litellm_call_id", None),
            "api_base": get_api_base(model=model or "", optional_params=kwargs),
            "model_id": model_id,
            "response_cost": logging_obj.response_cost_calculator(
                result=self.result,
                litellm_model_name=model,
                router_model_id=model_id,
                cache_hit=cache_hit,
            ),
            "additional_headers": process_response_headers(
                self._get_additional_headers_from_hidden_params() or {},
                preserve_litellm_internal_headers=True,
            ),
            "litellm_model_name": model,
            "provider_response_model": _existing_provider_response_model(self.result)
            or _provider_response_model(self.result),
        }
        self._update_hidden_params(new_params)

    def _update_hidden_params(self, new_params: Mapping[str, object]) -> None:
        """
        Update hidden params - handles when self._hidden_params is a dict or HiddenParams object
        """
        # Handle both dict and HiddenParams cases
        if isinstance(self._hidden_params, dict):
            self._hidden_params.update(new_params)
        elif isinstance(self._hidden_params, HiddenParams):
            # For HiddenParams object, set attributes individually
            for key, value in new_params.items():
                setattr(self._hidden_params, key, value)

    def _get_additional_headers_from_hidden_params(self) -> httpx.Headers | dict[str, str] | None:
        """Get `additional_headers` from hidden params - handles when self._hidden_params is a dict or HiddenParams object"""
        if isinstance(self._hidden_params, dict):
            return self._hidden_params.get("additional_headers", None)
        elif isinstance(self._hidden_params, HiddenParams):
            return getattr(self._hidden_params, "additional_headers", None)

    def set_timing_metrics(
        self,
        start_time: datetime.datetime,
        end_time: datetime.datetime,
        logging_obj: LiteLLMLoggingObject,
        include_overhead: bool = True,
    ) -> None:
        """Set response timing metrics"""
        timing_metrics: Final = response_timing_metrics(start_time, end_time, logging_obj, include_overhead)
        total_response_time_ms: Final = timing_metrics["_response_ms"]

        # Set total response time if supported
        if self.supports_response_time:
            self.result._response_ms = total_response_time_ms

        #########################################################
        # 1. Add _response_ms total duration and the LiteLLM overhead within it
        #    (total minus the cache read on a cache hit, else total minus the provider call)
        #########################################################
        self._update_hidden_params(timing_metrics)

        #########################################################
        # 2. Add callback processing duration
        #########################################################
        callback_duration_ms: Final[float | None] = getattr(logging_obj, "callback_duration_ms", None)
        if callback_duration_ms is not None:
            self._update_hidden_params(
                {
                    "callback_duration_ms": round(callback_duration_ms, 4),
                }
            )

        #########################################################
        # 3. Detailed per-phase timing (opt-in via env var)
        #########################################################
        llm_api_duration_ms: Final[float | None] = logging_obj.model_call_details.get("llm_api_duration_ms")
        if LITELLM_DETAILED_TIMING and llm_api_duration_ms is not None:
            detailed: Final[dict[str, float]] = {
                "timing_llm_api_ms": round(llm_api_duration_ms, 4),
            }

            # message copy time from Logging.__init__()
            msg_copy_ms: Final[float | None] = getattr(logging_obj, "message_copy_duration_ms", None)
            if msg_copy_ms is not None:
                detailed["timing_message_copy_ms"] = round(msg_copy_ms, 4)

            # pre-processing = time from request start to LLM API call start
            api_call_start: Final[datetime.datetime | None] = logging_obj.model_call_details.get("api_call_start_time")
            if api_call_start is not None and start_time is not None:
                anchor: Final = _timing_window_start(start_time, logging_obj)[0]
                pre_ms: Final = (api_call_start.timestamp() - anchor.timestamp()) * 1000
                detailed["timing_pre_processing_ms"] = round(pre_ms, 4)

                # post-processing = total - pre - llm_api
                post_ms: Final = total_response_time_ms - pre_ms - llm_api_duration_ms
                detailed["timing_post_processing_ms"] = round(max(post_ms, 0), 4)

            self._update_hidden_params(detailed)

    def apply(self) -> None:
        """Apply metadata to the response object"""
        if hasattr(self.result, "_hidden_params"):
            self.result._hidden_params = self._hidden_params


def update_response_metadata(
    result: object,
    logging_obj: LiteLLMLoggingObject,
    model: str | None,
    kwargs: dict,
    start_time: datetime.datetime,
    end_time: datetime.datetime,
    include_overhead: bool = True,
    cache_hit: bool | None = None,
) -> None:
    """
    Updates response metadata including hidden params and timing metrics
    Updates response metadata, adds the following:
        - response._hidden_params
        - response._hidden_params["litellm_overhead_time_ms"]
        - response.response_time_ms
    A result that cannot hold ``_hidden_params`` gets its timing on ``logging_obj`` instead.
    Callers whose ``end_time`` covers more than the recorded provider call (a stream read to
    completion) pass ``include_overhead=False``, since the overhead cannot be derived there.
    """
    if result is None:
        return
    if not hasattr(result, "_hidden_params"):
        # /v1/messages returns a plain dict and the Anthropic / Responses bridge stream wrappers
        # cannot hold ``_hidden_params``: keep only the timing on the logging object (no cost
        # recompute) so the proxy headers and the standard logging payload can still read it.
        logging_obj.set_response_timing_metrics(
            response_timing_metrics(start_time, end_time, logging_obj, include_overhead)
        )
        return

    metadata: Final = ResponseMetadata(result)
    metadata.set_timing_metrics(start_time, end_time, logging_obj, include_overhead)
    metadata.set_hidden_params(logging_obj, model, kwargs, cache_hit=cache_hit)
    metadata.apply()
