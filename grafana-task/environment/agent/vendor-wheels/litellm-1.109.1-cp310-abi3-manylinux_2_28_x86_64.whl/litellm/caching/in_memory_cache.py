"""
In-Memory Cache implementation

Has 4 methods:
    - set_cache
    - get_cache
    - async_set_cache
    - async_get_cache
"""

import heapq
import json
import sys
import threading
import time
from collections.abc import Callable
from typing import TYPE_CHECKING, Any, Final

if TYPE_CHECKING:
    from litellm.types.caching import RedisPipelineIncrementOperation

from pydantic import BaseModel

from litellm.constants import MAX_SIZE_PER_ITEM_IN_MEMORY_CACHE_IN_KB

from .base_cache import BaseCache

DEFAULT_MAX_SIZE_IN_MEMORY: Final = 200


class InMemoryCache(BaseCache):
    def __init__(
        self,
        max_size_in_memory: int | None = DEFAULT_MAX_SIZE_IN_MEMORY,
        default_ttl: int
        | None = 600,  # default ttl is 10 minutes. At maximum litellm rate limiting logic requires objects to be in memory for 1 minute
        max_size_per_item: int | None = 1024,  # 1MB = 1024KB
        clock: Callable[[], float] | None = None,
    ):
        """
        max_size_in_memory [int]: Maximum number of items in cache. done to prevent memory leaks. Use 200 items as a default
        """
        self.max_size_in_memory = (
            max_size_in_memory if max_size_in_memory is not None else DEFAULT_MAX_SIZE_IN_MEMORY
        )  # set an upper bound of 200 items in-memory
        self.default_ttl = default_ttl or 600
        self.max_size_per_item = max_size_per_item or MAX_SIZE_PER_ITEM_IN_MEMORY_CACHE_IN_KB  # 1MB = 1024KB

        # in-memory cache
        self.cache_dict: dict = {}
        self.ttl_dict: dict = {}
        self.expiration_heap: list[tuple[float, str]] = []
        self._increment_lock = threading.Lock()
        self._write_lock = threading.Lock()
        self._clock = clock if clock is not None else lambda: time.time()

    def check_value_size(self, value: Any):
        """
        Check if value size exceeds max_size_per_item (1MB)
        Returns True if value size is acceptable, False otherwise
        """
        try:
            # Fast path for common primitive types that are typically small
            if (
                isinstance(value, (bool, int, float, str))
                and len(str(value)) < self.max_size_per_item * MAX_SIZE_PER_ITEM_IN_MEMORY_CACHE_IN_KB
            ):  # Conservative estimate
                return True

            # Direct size check for bytes objects
            if isinstance(value, bytes):
                return sys.getsizeof(value) / 1024 <= self.max_size_per_item

            # Handle special types without full conversion when possible
            if hasattr(value, "__sizeof__"):  # Use __sizeof__ if available
                size: Final = value.__sizeof__() / 1024
                return size <= self.max_size_per_item

            # Fallback for complex types
            if isinstance(value, BaseModel) and hasattr(value, "model_dump"):  # Pydantic v2
                value = value.model_dump()
            elif hasattr(value, "isoformat"):  # datetime objects
                return True  # datetime strings are always small

            # Only convert to JSON if absolutely necessary
            if not isinstance(value, (str, bytes)):
                value = json.dumps(value, default=str)

            return sys.getsizeof(value) / 1024 <= self.max_size_per_item

        except Exception:
            return False

    def _is_key_expired(self, key: str) -> bool:
        """
        Check if a specific key is expired
        """
        try:
            return self._clock() > self.ttl_dict[key]
        except KeyError:
            return False

    def _cache_keys(self) -> tuple[str, ...]:
        return tuple(self.cache_dict)  # pyright: ignore[reportUnknownVariableType]  # cache_dict is untyped legacy state

    def _remove_key(self, key: str) -> None:
        """
        Remove a key from both cache_dict and ttl_dict
        """
        self.cache_dict.pop(key, None)
        self.ttl_dict.pop(key, None)

    def evict_cache(self):
        """
        Eviction policy:
        1. First, remove expired items from ttl_dict and cache_dict
        2. If cache is still at or above max_size_in_memory, evict items with earliest expiration times


        This guarantees the following:
        - 1. When item ttl not set: At minimum each item will remain in memory for the default ttl
        - 2. When ttl is set: the item will remain in memory for at least that amount of time, unless cache size requires eviction
        - 3. the size of in-memory cache is bounded

        """
        current_time: Final = self._clock()

        # Step 1: Remove expired or outdated items
        while self.expiration_heap:
            expiration_time, key = self.expiration_heap[0]

            # Case 1: Heap entry is outdated
            if expiration_time != self.ttl_dict.get(key):
                heapq.heappop(self.expiration_heap)
            # Case 2: Entry is valid but expired
            elif expiration_time <= current_time:
                heapq.heappop(self.expiration_heap)
                self._remove_key(key)
            else:
                # Case 3: Entry is valid and not expired
                break

        if len(self.expiration_heap) > 2 * self.max_size_in_memory:
            self.expiration_heap = [entry for entry in self.expiration_heap if self.ttl_dict.get(entry[1]) == entry[0]]
            heapq.heapify(self.expiration_heap)

        # Step 2: Evict if cache is still full
        while self.expiration_heap and len(self.cache_dict) >= self.max_size_in_memory:
            expiration_time, key = heapq.heappop(self.expiration_heap)
            # Skip if key was removed or updated
            if self.ttl_dict.get(key) == expiration_time:
                self._remove_key(key)

        if not self.expiration_heap:
            untracked_keys: Final = self._cache_keys()
            overflow: Final = len(untracked_keys) - self.max_size_in_memory + 1
            for untracked_key in untracked_keys[: max(overflow, 0)]:
                self._remove_key(untracked_key)

        # de-reference the removed item
        # https://www.geeksforgeeks.org/diagnosing-and-fixing-memory-leaks-in-python/
        # One of the most common causes of memory leaks in Python is the retention of objects that are no longer being used.
        # This can occur when an object is referenced by another object, but the reference is never removed.

    def allow_ttl_override(self, key: str) -> bool:
        """
        Check if ttl is set for a key
        """
        ttl_time: Final = self.ttl_dict.get(key)
        if ttl_time is None or ttl_time < self._clock():  # if ttl is not set, allow override
            return True
        else:
            return False

    def set_cache(self, key, value, **kwargs):
        # Handle the edge case where max_size_in_memory is 0
        if self.max_size_in_memory == 0:
            return  # Don't cache anything if max size is 0

        with self._write_lock:
            # Always prune expired/outdated heap roots before inserting.
            # This keeps expiration_heap bounded even when the live cache stays
            # below max_size_in_memory and keys are reinserted after TTL expiry.
            self.evict_cache()
            if not self.check_value_size(value):
                return

            self.cache_dict[key] = value
            if self.allow_ttl_override(key):  # if ttl is not set, set it to default ttl
                if "ttl" in kwargs and kwargs["ttl"] is not None:
                    self.ttl_dict[key] = self._clock() + float(kwargs["ttl"])
                    heapq.heappush(self.expiration_heap, (self.ttl_dict[key], key))
                else:
                    self.ttl_dict[key] = self._clock() + self.default_ttl
                    heapq.heappush(self.expiration_heap, (self.ttl_dict[key], key))

    async def async_set_cache(self, key, value, **kwargs):
        self.set_cache(key=key, value=value, **kwargs)

    async def async_set_cache_pipeline(self, cache_list, ttl=None, **kwargs):
        for cache_key, cache_value in cache_list:
            if ttl is not None:
                self.set_cache(key=cache_key, value=cache_value, ttl=ttl)
            else:
                self.set_cache(key=cache_key, value=cache_value)

    async def async_set_cache_sadd(self, key, value: list, ttl: float | None):
        """
        Add value to set
        """
        # get the value
        init_value: Final = self.get_cache(key=key) or set()
        for val in value:
            init_value.add(val)
        self.set_cache(key, init_value, ttl=ttl)
        return value

    def evict_element_if_expired(self, key: str) -> bool:
        """
        Returns True if the element is expired and removed from the cache

        Returns False if the element is not expired
        """
        if self._is_key_expired(key):
            self._remove_key(key)
            return True
        return False

    def get_cache(self, key, **kwargs):
        if key in self.cache_dict:
            if self.evict_element_if_expired(key):
                return None
            try:
                original_cached_response: Final = self.cache_dict[key]
            except KeyError:
                return None
            try:
                cached_response = json.loads(original_cached_response)
            except Exception:
                cached_response = original_cached_response
            return cached_response
        return None

    def batch_get_cache(self, keys: list, **kwargs):
        return_val: Final = []
        for k in keys:
            val = self.get_cache(key=k, **kwargs)
            return_val.append(val)
        return return_val

    def increment_cache(self, key, value: float, **kwargs) -> float:
        with self._increment_lock:
            # keep read-modify-write atomic
            init_value: Final = self.get_cache(key=key) or 0
            value = init_value + value
            self.set_cache(key, value, **kwargs)
            return value

    async def async_get_cache(self, key, **kwargs):
        return self.get_cache(key=key, **kwargs)

    async def async_batch_get_cache(self, keys: list, **kwargs):
        return_val: Final = []
        for k in keys:
            val = self.get_cache(key=k, **kwargs)
            return_val.append(val)
        return return_val

    async def async_increment(self, key, value: float, **kwargs) -> float:
        return self.increment_cache(key=key, value=value, **kwargs)

    async def async_increment_pipeline(
        self, increment_list: list["RedisPipelineIncrementOperation"], **kwargs
    ) -> list[float] | None:
        results: Final = []
        for increment in increment_list:
            result = await self.async_increment(
                increment["key"], increment["increment_value"], ttl=increment["ttl"], **kwargs
            )
            results.append(result)
        return results

    def flush_cache(self):
        with self._write_lock:
            self.cache_dict.clear()
            self.ttl_dict.clear()
            self.expiration_heap.clear()

    async def disconnect(self):
        pass

    def delete_cache(self, key: str) -> None:
        self._remove_key(key)

    async def async_get_ttl(self, key: str) -> int | None:
        """
        Get the remaining TTL of a key in in-memory cache
        """
        return self.ttl_dict.get(key, None)

    async def async_get_oldest_n_keys(self, n: int) -> list[str]:
        """
        Get the oldest n keys in the cache
        """
        # sorted ttl dict by ttl
        sorted_ttl_dict: Final = sorted(self.ttl_dict.items(), key=lambda x: x[1])
        return [key for key, _ in sorted_ttl_dict[:n]]
