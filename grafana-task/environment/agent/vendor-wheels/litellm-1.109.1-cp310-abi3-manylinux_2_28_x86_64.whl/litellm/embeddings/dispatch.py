import inspect
from collections.abc import Awaitable, Callable, Coroutine, Mapping
from typing import Final, TypeAlias, cast  # noqa: TID251  # native binding selects a sync result or an async awaitable

from litellm import main
from litellm.rust_bridge.catalog import Route, RouteContext
from litellm.rust_bridge.dispatch import PublicDispatch
from litellm.rust_bridge.embeddings.entrypoints import (
    NATIVE_AEMBEDDING,
    NATIVE_EMBEDDING,
)
from litellm.rust_bridge.public_call import (
    AsyncFlag,
    NativeCall,
    bind,
    native_call,
    native_call_hook,
    optional_str,
    signature,
)
from litellm.types.utils import EmbeddingResponse

__all__ = ("aembedding", "embedding")

PythonEmbedding: TypeAlias = Callable[..., EmbeddingResponse | Coroutine[object, object, EmbeddingResponse]]
PythonAembedding: TypeAlias = Callable[..., Awaitable[EmbeddingResponse]]

_PYTHON_EMBEDDING: Final = cast(  # cast-ok: [LIT006] preserve the legacy public callable contract
    PythonEmbedding, main.embedding
)
_PYTHON_AEMBEDDING: Final = cast(  # cast-ok: [LIT006] preserve the legacy public callable contract
    PythonAembedding, main.aembedding
)
_EMBEDDING_SIGNATURE: Final = signature(_PYTHON_EMBEDDING)
_FLAG: Final = AsyncFlag("aembedding", sync=_EMBEDDING_SIGNATURE)


def _public_request(
    legacy: inspect.Signature, args: tuple[object, ...], kwargs: Mapping[str, object]
) -> NativeCall | None:
    fields: Final = bind(legacy, args, kwargs)
    if fields is None:
        return None
    model: Final = fields.get("model")
    if not isinstance(model, str):
        return None
    return native_call(legacy, args, kwargs)


def _context(request: NativeCall) -> RouteContext:
    return RouteContext(
        Route.EMBEDDINGS,
        provider=optional_str(request.resolved.get("custom_llm_provider")),
        model=str(request.resolved["model"]),
    )


_DISPATCH: Final = PublicDispatch(
    route=Route.EMBEDDINGS,
    request=lambda args, kwargs: _public_request(_EMBEDDING_SIGNATURE, args, kwargs),
    context=_context,
)

_ADISPATCH: Final = PublicDispatch(
    route=Route.EMBEDDINGS,
    request=lambda args, kwargs: _public_request(_EMBEDDING_SIGNATURE, args, kwargs),
    context=_context,
)


def embedding(
    *args: object,
    **kwargs: object,  # kwargs-ok: preserve the public embedding call shape
) -> EmbeddingResponse | Coroutine[object, object, EmbeddingResponse]:
    if _FLAG.requested(kwargs):
        return aembedding(**_FLAG.keywords(args, kwargs))
    return _DISPATCH.run(
        args,
        _FLAG.dropped(kwargs),
        python=_PYTHON_EMBEDDING,
        binding=NATIVE_EMBEDDING,
        native=native_call_hook,
    )


async def aembedding(*args: object, **kwargs: object) -> EmbeddingResponse:  # kwargs-ok: preserve the public call shape
    return await _ADISPATCH.arun(
        args,
        _FLAG.dropped(kwargs),
        python=_PYTHON_AEMBEDDING,
        binding=NATIVE_AEMBEDDING,
        native=native_call_hook,
    )


embedding.__doc__ = _PYTHON_EMBEDDING.__doc__
embedding.__wrapped__ = _PYTHON_EMBEDDING  # pyright: ignore[reportFunctionMemberAccess]  # preserve the legacy signature
aembedding.__doc__ = _PYTHON_AEMBEDDING.__doc__
aembedding.__wrapped__ = _PYTHON_AEMBEDDING  # pyright: ignore[reportFunctionMemberAccess]  # preserve the legacy signature
